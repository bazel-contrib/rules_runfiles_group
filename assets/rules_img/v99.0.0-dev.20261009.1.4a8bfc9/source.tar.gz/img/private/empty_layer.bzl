"""Rule for producing an empty OCI layer with application/vnd.oci.empty.v1+json media type."""

load("//img/private/providers:layers_info.bzl", "LayersInfo")
load("//img/private/providers:single_layer_info.bzl", "SingleLayerInfo")

def _empty_layer_impl(ctx):
    blob_data = "{}"
    media_type = "application/vnd.oci.empty.v1+json"
    metadata = dict(
        mediaType = media_type,
        digest = "sha256:44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
        size = len(blob_data),
    )
    out = ctx.actions.declare_file(ctx.attr.name + ".json")
    metadata_out = ctx.actions.declare_file(ctx.attr.name + "_metadata.json")
    ctx.actions.write(out, blob_data)
    ctx.actions.write(metadata_out, json.encode(metadata))
    return [
        DefaultInfo(files = depset([out])),
        OutputGroupInfo(
            layer = depset([out]),
            metadata = depset([metadata_out]),
        ),
        LayersInfo(layers = [SingleLayerInfo(
            blob = out,
            metadata = metadata_out,
            media_type = media_type,
            estargz = False,
            compact_stream = None,
            layer_input_files = None,
            layer_input_files_cas = None,
            sources = [],
            mtree = None,
            ztoc = None,
        )]),
    ]

empty_layer = rule(
    implementation = _empty_layer_impl,
    provides = [LayersInfo],
)
