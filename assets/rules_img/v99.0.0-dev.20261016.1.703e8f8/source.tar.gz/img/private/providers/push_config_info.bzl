"""Defines the PushConfigInfo provider for push configuration without an image reference."""

DOC = """\
Push configuration for deploying images to a registry. Captures registry,
repository, tags, and strategy without referencing a specific image.
"""

FIELDS = dict(
    registry = "Registry URL template string.",
    repository = "Repository template string.",
    tags = "List of tag template strings (combined from tag/tag_list).",
    manifest_tags = "Per-platform tag template strings for multi-platform pushes.",
    tag_file = "File with newline-delimited tags, or None.",
    destination_file = "File containing {registry}/{repository}, or None.",
    referrers = "List of structs(manifest_info, index_info) for referrer pushes.",
    cross_mount_from = "Target providing DeployInfo for cross-mounting, or None.",
    strategy = "Resolved push strategy string (never 'auto').",
    cross_mount_strategy = "Resolved cross-mount strategy string.",
    build_settings = "Dict(string, string) of resolved build setting values.",
    stamp = "Stamp preference string ('auto', 'force', 'disabled').",
    stamp_settings = "StampSettingInfo provider for stamp resolution.",
    tracks_content = "Bool: when True, expose the image digest to templates and re-stamp tags on content change.",
    signing = "struct(config_info, best_effort, targets) describing how to sign this push, or None.",
    blob_repository = "Resolved staging repository that image blobs are pushed to and cross-mounted from. At build time every blob (layers and config) is staged here; layers are cross-mounted into the image's real repository. Empty means blobs go to the image's own repository.",
    forbid_layer_push = "Bool: when True, `img deploy` refuses to upload layer blob bytes (layers must be cross-mounted or already present).",
    deduplicated_push = "Resolved deduplicated push mode: 'disabled', 'best_effort' or 'enabled'. When not 'disabled', `img deploy` pushes in phases -- check which manifests the registry already has, upload each blob that several repositories need to just one of them (the first alphabetically, or a staging/pinned repository), then cross-mount it into the others. For registries that keep a separate blob store per repository name. 'enabled' requires cross-repository blob mounting and fails a push where mounting is refused; 'best_effort' uploads the layer the ordinary way instead. See docs/registry-support.md.",
    deduplicated_push_blob_repository = "Resolved repository that every blob the deduplicated push shares between repositories is uploaded to and cross-mounted from, ahead of any home repository the deploy would have picked itself, or '' to let the deploy pick one per blob.",
    deduplicated_push_content = "Resolved deduplicated push content: 'blobs' or 'blobs_and_artificial_manifests' (which also writes a config blob and a manifest referencing the shared blob to its home repository).",
    push_at_build_time_mode = "Resolved push-at-build-time mode: 'disabled', 'best_effort', or 'enabled'.",
    push_at_build_time_content = "Resolved push-at-build-time content: 'blobs', 'blobs_and_manifests' (manifests by digest, no tags) or 'all' (manifests and tags).",
    push_at_build_time_manifest_repository = "Resolved repository the build-time manifest push uploads manifest(s)/index and config to instead of the operation's own repository, or ''. Does not affect blob cross-mounting.",
    push_at_build_time_exec_properties = "Dict(string, string) of execution_requirements forwarded to the PushImage build-time push actions.",
    push_at_build_time_output_group = "Resolved output group that drives the build-time pushes: 'validation' (also wired into the implicit `_validation` group, so they run on every build) or 'push_at_build_time' (only run when requested with --output_groups=+push_at_build_time).",
    push_at_build_time_gateway = "Shared OCI distribution gateway endpoint for the build-time push actions, or ''.",
    push_at_build_time_push_gateway = "Push OCI distribution gateway endpoint for the build-time push actions, or ''.",
    push_at_build_time_pull_gateway = "Pull OCI distribution gateway endpoint for the build-time push actions, or ''.",
    insecure = "Bool: when True, the build-time push actions address registries over plain HTTP and accept untrusted TLS certificates (IMG_INSECURE).",
)

PushConfigInfo = provider(
    doc = DOC,
    fields = FIELDS,
)
