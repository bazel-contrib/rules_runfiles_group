---
trigger: always_on
---

# Workspace Rules

To avoid confusion from using outdated code states, when starting a new
conversation/session or when first starting a new branch or worktree, unless
explicitly instructed otherwise, ensure the latest upstream code is used as the
basis:
* Fetch `upstream/main` (`git fetch upstream main`).
* Base any new branch or worktree upon `upstream/main` (e.g.,
  `git checkout -b <branch> upstream/main`).
* Run the workspace helper script to configure upstream tracking and safe
  pushing:
  ```bash
  .agents/scripts/setup_triangle_branch.sh <branch>
  ```
* Never use `git push -u` or `--set-upstream` (it breaks upstream tracking).
* When pushing to a checked-out PR branch from an external fork, push
  explicitly to that remote (`git push <remote> HEAD:<branch>`). Do not rely on
  a bare `git push`.
* When syncing a branch with `upstream/main`, commit or stash local changes
  *before* running `git merge upstream/main` and conclude the merge in its own
  dedicated commit. Never run `git stash` while `MERGE_HEAD` is active, as
  `git stash` clears `MERGE_HEAD`.
