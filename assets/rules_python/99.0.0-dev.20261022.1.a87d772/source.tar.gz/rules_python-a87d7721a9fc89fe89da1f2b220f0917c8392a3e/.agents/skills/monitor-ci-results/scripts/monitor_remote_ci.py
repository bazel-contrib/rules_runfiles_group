#!/usr/bin/env python3

import argparse
import fcntl
import json
import os
import re
import subprocess
import sys
import time
import urllib.request


def check_cli(cmd_name):
    try:
        subprocess.run(
            [cmd_name, "--version"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except Exception:
        return False


def get_pr_checks(pr_number):
    if not check_cli("gh"):
        print("❌ 'gh' CLI not installed.", file=sys.stderr)
        return []
    cmd = ["gh", "pr", "checks", str(pr_number), "--json", "name,link,state,bucket"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True)
        out = res.stdout
        json_str = out[out.find("[") : out.rfind("]") + 1] if "[" in out else "[]"
        return json.loads(json_str)
    except Exception as e:
        print(f"⚠️ Error fetching PR checks: {e}", file=sys.stderr)
        return []


def get_buildkite_jobs(build_url):
    base_url = build_url.split("#")[0]
    if base_url.endswith(".json"):
        base_url = base_url[:-5]

    m = re.search(r"buildkite\.com/([^/]+/[^/]+)/builds/(\d+)", base_url)
    if m and check_cli("bk"):
        pipeline, build_number = m.group(1), m.group(2)
        try:
            res = subprocess.run(
                ["bk", "build", "view", build_number, "-p", pipeline, "--json"],
                capture_output=True,
                text=True,
                check=True,
            )
            data = json.loads(res.stdout)
            if isinstance(data, dict) and "jobs" in data:
                return data["jobs"]
        except Exception as e:
            print(
                f"⚠️ Could not fetch Buildkite jobs via bk CLI for {pipeline}#{build_number}: {e}",
                file=sys.stderr,
            )

    jobs_url = f"{base_url}/data/jobs.json"
    req = urllib.request.Request(jobs_url, headers={"User-Agent": "ci-monitor"})
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            if isinstance(data, list):
                return data
            elif isinstance(data, dict) and "records" in data:
                return data["records"]
    except Exception as e:
        print(
            f"⚠️ Could not fetch Buildkite jobs from {jobs_url}: {e}",
            file=sys.stderr,
        )
    return []


def main():
    parser = argparse.ArgumentParser(
        description="Monitor remote CI for failures and trigger analysis."
    )
    parser.add_argument("pr", help="PR number to monitor")
    parser.add_argument("conv_id", help="Conversation ID to report back to")
    parser.add_argument(
        "--interval",
        type=int,
        default=60,
        help="Monitoring polling interval in seconds",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=120,
        help="Maximum number of polling cycles",
    )
    args = parser.parse_args()

    skill_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    scratch_dir = os.path.join(skill_dir, "scratch")
    os.makedirs(scratch_dir, exist_ok=True)

    # Acquire lock for PR to avoid duplicate monitoring processes
    lock_file_path = os.path.join(scratch_dir, f".monitored_pr_{args.pr}.lock")
    lock_file = open(lock_file_path, "a+")
    running_agent_conv_id = os.environ.get("ANTIGRAVITY_CONVERSATION_ID", "")
    try:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_file.seek(0)
        lock_file.truncate(0)
        lock_data = {
            "pid": os.getpid(),
            "agent_conv_id": running_agent_conv_id,
            "notify_conv_id": args.conv_id,
        }
        lock_file.write(json.dumps(lock_data) + "\n")
        lock_file.flush()
    except (BlockingIOError, OSError):
        existing_agent_conv = ""
        try:
            lock_file.seek(0)
            content = lock_file.read().strip()
            if content:
                data = json.loads(content)
                existing_agent_conv = data.get("agent_conv_id", "") or data.get(
                    "conv_id", ""
                )
        except Exception:
            pass

        subagent_str = (
            f" under agent/subagent conversation '{existing_agent_conv}'"
            if existing_agent_conv
            else ""
        )
        print(
            f"ℹ️ Continuous remote CI monitoring for PR #{args.pr} is already running in another process{subagent_str}. Exiting."
        )
        sys.exit(0)

    state_file = os.path.join(scratch_dir, f"monitored_state_pr_{args.pr}.json")
    monitored = {}
    if os.path.exists(state_file):
        try:
            with open(state_file) as f:
                monitored = json.load(f)
        except Exception:
            pass

    print(
        f"🚀 Starting continuous remote CI monitoring for PR #{args.pr} every {args.interval}s..."
    )

    for i in range(args.max_iterations):
        print(
            f"🔍 [Cycle {i + 1}/{args.max_iterations}] Polling GitHub PR #{args.pr} checks..."
        )
        checks = get_pr_checks(args.pr)

        for check in checks:
            name = check.get("name", "unknown")
            state = check.get("state", "UNKNOWN")
            link = check.get("link", "")
            bucket = check.get("bucket", "")

            if "buildkite" in name.lower() and link:
                jobs = get_buildkite_jobs(link)

                passed = 0
                failed = 0
                running = 0
                blocked = 0
                other = 0

                for job in jobs:
                    if job.get("retried_in_job_uuid") or job.get("retried_at"):
                        continue
                    jstate = job.get("state", "unknown")
                    exit_status = job.get("exit_status")
                    is_soft_failed = job.get("soft_failed") is True
                    is_blocked = jstate in ["blocked", "blocked_failed"]
                    is_failed = (
                        (
                            jstate in ["failed", "failing"]
                            or (exit_status != 0 and exit_status is not None)
                        )
                        and not is_soft_failed
                        and not is_blocked
                    )
                    is_passed = (
                        jstate in ["passed", "success"]
                        or (jstate == "finished" and exit_status == 0)
                        or is_soft_failed
                    ) and not is_blocked
                    is_running = jstate in ["running", "scheduled"] and not is_blocked

                    if is_blocked:
                        blocked += 1
                    elif is_failed:
                        failed += 1
                    elif is_passed:
                        passed += 1
                    elif is_running:
                        running += 1
                    else:
                        other += 1

                build_id = link.split("/")[-1].split("#")[0]
                print(
                    f"Buildkite #{build_id}: {len(jobs)} total jobs "
                    f"(Passed: {passed}, Failed: {failed}, Running: {running}, Blocked: {blocked}, Other: {other})"
                )

                for job in jobs:
                    if job.get("retried_in_job_uuid") or job.get("retried_at"):
                        continue
                    jname = job.get("name") or job.get("label") or "unknown_job"
                    jstate = job.get("state", "unknown")
                    jid = job.get("id", "")
                    jkey = f"bk_{jid}"
                    log_url = job.get("web_url") or job.get("log_url") or link

                    exit_status = job.get("exit_status")
                    is_soft_failed = job.get("soft_failed") is True
                    is_blocked = jstate in ["blocked", "blocked_failed"]
                    is_manual_block = (
                        job.get("type") == "manual" or job.get("unblockable") is True
                    )
                    is_failed = (
                        (
                            jstate in ["failed", "failing"]
                            or (exit_status != 0 and exit_status is not None)
                        )
                        and not is_soft_failed
                        and not is_blocked
                    )

                    if is_blocked and is_manual_block:
                        jkey_blocked = f"bk_blocked_{jid}"
                        if jkey_blocked not in monitored:
                            unblocked = False
                            if jid and check_cli("bk"):
                                print(
                                    f"🔓 Automatically unblocking Buildkite approval step '{jname}' (ID: {jid})..."
                                )
                                res = subprocess.run(
                                    ["bk", "job", "unblock", jid, "--no-input"]
                                )
                                unblocked = res.returncode == 0

                            if not unblocked:
                                print(
                                    f"⏸️ Notifying blocked state for Buildkite job '{jname}' (ID: {jid})..."
                                )
                                msg = (
                                    f"⚠️ Remote CI Buildkite Job '{jname}' is blocked!\n\n"
                                    f"Build ID: {build_id} | Job ID: {jid}\n"
                                    f"Log URL: {log_url}\n\n"
                                    f"Action required: Unblock the job using the buildkite-retry-job skill (`retry_buildkite_jobs.py {args.pr} --unblock`)."
                                )
                                subprocess.run(
                                    [
                                        "agentapi",
                                        "send-message",
                                        "--title=CI Job Blocked",
                                        args.conv_id,
                                        msg,
                                    ]
                                )
                            monitored[jkey_blocked] = time.time()
                            with open(state_file, "w") as f:
                                json.dump(monitored, f)

                    elif is_failed and jkey not in monitored:
                        print(
                            f"🚨 Notifying failure for Buildkite job '{jname}' (ID: {jid})..."
                        )
                        msg = (
                            f"⚠️ Remote CI Buildkite Job '{jname}' completed with errors!\n\n"
                            f"Build ID: {build_id} | Job ID: {jid}\n"
                            f"Log URL: {log_url}\n\n"
                            f"Action required: Start a subagent to run the analyze-ci-failure skill for '{jname}' with build ID '{build_id}' and job ID '{jid}'."
                        )
                        subprocess.run(
                            [
                                "agentapi",
                                "send-message",
                                "--title=CI Job Failed",
                                args.conv_id,
                                msg,
                            ]
                        )
                        monitored[jkey] = time.time()
                        with open(state_file, "w") as f:
                            json.dump(monitored, f)

            elif (
                state.upper() in ["ACTION_REQUIRED", "BLOCKED"]
                and f"gh_blocked_{name}" not in monitored
            ):
                print(f"⏸️ Notifying blocked state for GitHub check '{name}'...")
                msg = (
                    f"⚠️ Remote CI GitHub Check '{name}' is blocked!\n\n"
                    f"Link: {link}\n\n"
                    f"The user must confirm whether to run the CI jobs."
                )
                subprocess.run(
                    [
                        "agentapi",
                        "send-message",
                        "--title=CI Check Blocked",
                        args.conv_id,
                        msg,
                    ]
                )
                monitored[f"gh_blocked_{name}"] = time.time()
                with open(state_file, "w") as f:
                    json.dump(monitored, f)

            elif (
                state.upper() in ["FAILURE", "FAIL", "CANCELLED", "TIMED_OUT"]
                or bucket == "fail"
            ) and name not in monitored:
                print(f"🚨 Notifying failure for GitHub check '{name}'...")
                job_id = link.split("/")[-1] if "/" in link else link
                msg = (
                    f"⚠️ Remote CI GitHub Check '{name}' completed with errors!\n\n"
                    f"Link: {link}\n\n"
                    f"Action required: Start a subagent to run the analyze-ci-failure skill for '{name}' with link '{link}' and job ID '{job_id}'."
                )
                subprocess.run(
                    [
                        "agentapi",
                        "send-message",
                        "--title=CI Check Failed",
                        args.conv_id,
                        msg,
                    ]
                )
                monitored[name] = time.time()
                with open(state_file, "w") as f:
                    json.dump(monitored, f)

        time.sleep(args.interval)

    print("🏁 CI monitoring service completed its scheduled iterations.")


if __name__ == "__main__":
    main()
