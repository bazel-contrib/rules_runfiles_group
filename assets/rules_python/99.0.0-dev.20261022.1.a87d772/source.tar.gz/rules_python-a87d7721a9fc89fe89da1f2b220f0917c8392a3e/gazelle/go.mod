module github.com/bazel-contrib/rules_python/gazelle

go 1.22.9

toolchain go1.24.13

require (
	github.com/bazelbuild/bazel-gazelle v0.47.0
	github.com/bazelbuild/buildtools v0.0.0-20250930140053-2eb4fccefb52
	github.com/bazelbuild/rules_go v0.55.1
	github.com/bmatcuk/doublestar/v4 v4.9.1
	github.com/emirpasic/gods v1.18.1
	github.com/ghodss/yaml v1.0.0
	github.com/stretchr/testify v1.9.0
	github.com/tree-sitter/go-tree-sitter v0.24.1-0.20251112183152-c9492002f76e
	github.com/tree-sitter/tree-sitter-python v0.25.0
	golang.org/x/sync v0.11.0
	gopkg.in/yaml.v2 v2.4.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/google/go-cmp v0.6.0 // indirect
	github.com/mattn/go-pointer v0.0.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/mod v0.23.0 // indirect
	golang.org/x/sys v0.30.0 // indirect
	golang.org/x/tools/go/vcs v0.1.0-deprecated // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
