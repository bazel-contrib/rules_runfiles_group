---
name: Release or Backport Tracking Issue
about: Checklist for tracking a new release, patch release, or backport of rules_python.
title: 'Release <version>'
labels: ['type: release']
---
# Release tasks
<!-- For patch releases and backports, only "Tag Final" is needed; delete the
other release tasks below. -->
- [ ] Prepare Release | status=awaiting-preparation
- [ ] Create Release branch
- [ ] Tag RC0
- [ ] Tag Final

## Backports
 
To request or track a backport, comment `/backport` on the PR, comment
`/backport <PR>` on this issue, or add it to the checklist below. See
[RELEASING.md: How to add backports](https://github.com/bazel-contrib/rules_python/blob/main/RELEASING.md#how-to-add-backports)
for details.
 
- [ ] #PR_NUMBER
 
---
 
To manually control the release flow, see the
[RELEASING.md: Manual Editing](https://github.com/bazel-contrib/rules_python/blob/main/RELEASING.md#manual-editing-of-tracking-issue)
section.
 
<details>
<summary><b>Available Commands</b></summary>
 
Comment commands:
- `/prepare`: Determines version, creates tracking issue and preparation PR.
- `/prepare-complete [PR]`: Marks preparation task as complete.
- `/create-release-branch`: Cuts and pushes the release branch.
- `/create-rc`: Tags and publishes a new release candidate (RC).
- `/process-backports`: Cherry-picks pending backports.
- `/sync-changelog`: Processes sync changelog tasks.
- `/backport <PRs>`: Adds PRs to the backports and processes backports.
- `/promote`: Promotes the latest RC to final release.
 
See [RELEASING.md](https://github.com/bazel-contrib/rules_python/blob/main/RELEASING.md) for details on how to use them.
</details>
