#!/usr/bin/env bash
# Copyright 2023 The Bazel Authors. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -o nounset
set -o pipefail
set -o errexit

set -x

TAG=${1:-}
if [ -n "$TAG" ]; then
  # If the workflow checks out one commit, but is releasing another
  git fetch origin tag "$TAG"
  git checkout "$TAG"
else
  TAG=$(git rev-parse HEAD)
fi

# A prefix is added to better match the GitHub generated archives.
PREFIX="rules_python-${TAG}"
ARCHIVE="rules_python-$TAG.tar.gz"
sed --in-place 's/^TOOL_DEPS_DEV_ONLY = False$/TOOL_DEPS_DEV_ONLY = True/' MODULE.bazel
# Verify that sed actually matched and modified the line (sed exits 0 even if no
# substitution occurred).
grep -q '^TOOL_DEPS_DEV_ONLY = True$' MODULE.bazel
# --add-file appends extra files to the archive without replacing tracked files
# from $TAG, so pathspec ":!..." excludes the committed files to avoid duplicate
# tar entries (where the committed ones would overwrite the modified ones on
# extraction).
git archive \
  --format=tar \
  "--prefix=${PREFIX}/" \
  "--add-file=MODULE.bazel" \
  "--prefix=${PREFIX}/python/private/" \
  "--add-file=artifacts_manifest.json" \
  "--prefix=${PREFIX}/" \
  "$TAG" \
  . \
  ":!MODULE.bazel" \
  ":!python/private/artifacts_manifest.json" | gzip > "$ARCHIVE"
SHA=$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')

cat > release_notes.txt << EOF

For more detailed setup instructions, see https://rules-python.readthedocs.io/en/latest/getting-started.html

For the user-facing changelog see [here](https://rules-python.readthedocs.io/en/latest/changelog.html#v${TAG//./-})

## Using Bzlmod

Add to your \`MODULE.bazel\` file:

\`\`\`starlark
bazel_dep(name = "rules_python", version = "${TAG}")

python = use_extension("@rules_python//python/extensions:python.bzl", "python")
python.toolchain(
    python_version = "3.14",
)

pip = use_extension("@rules_python//python/extensions:pip.bzl", "pip")
pip.parse(
    hub_name = "pypi",
    python_version = "3.14",
    requirements_lock = "//:requirements_lock.txt",
)

use_repo(pip, "pypi")
\`\`\`

## Using WORKSPACE

Paste this snippet into your \`WORKSPACE\` file:

\`\`\`starlark
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")

http_archive(
    name = "rules_python",
    sha256 = "${SHA}",
    strip_prefix = "${PREFIX}",
    url = "https://github.com/bazel-contrib/rules_python/releases/download/${TAG}/rules_python-${TAG}.tar.gz",
)

load("@rules_python//python:repositories.bzl", "py_repositories")

py_repositories()
\`\`\`

### Gazelle plugin

Paste this snippet into your \`WORKSPACE\` file:

\`\`\`starlark
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
http_archive(
    name = "rules_python_gazelle_plugin",
    sha256 = "${SHA}",
    strip_prefix = "${PREFIX}/gazelle",
    url = "https://github.com/bazel-contrib/rules_python/releases/download/${TAG}/rules_python-${TAG}.tar.gz",
)

# To compile the rules_python gazelle extension from source,
# we must fetch some third-party go dependencies that it uses.

load("@rules_python_gazelle_plugin//:deps.bzl", _py_gazelle_deps = "gazelle_deps")

_py_gazelle_deps()
\`\`\`
EOF
