:::{default-domain} bzl
:::

# rules_python Changelog

This is a human-friendly changelog in a keepachangelog.com style format.
Because this changelog is for end-user consumption of meaningful changes, only
a summary of a release's changes is described. This means every commit is not
necessarily mentioned, and internal refactors or code cleanups are omitted
unless they're particularly notable.

A brief description of the categories of changes:

* `Changed`: Some behavior changed. If the change is expected to break a
  public API or supported behavior, it will be marked as **BREAKING**. Note that
  beta APIs will not have breaking API changes called out.
* `Fixed`: A bug, or otherwise incorrect behavior, was fixed.
* `Added`: A new feature, API, or behavior was added in a backwards compatible
  manner.
* Particular sub-systems are identified using parentheses, e.g. `(bzlmod)` or
  `(docs)`.

{#unreleased}
## Unreleased

[unreleased]: https://github.com/bazel-contrib/rules_python/releases/tag/unreleased

Unreleased changes are tracked as individual files in the [news/](./news)
directory, or view the [latest generated
changelog](https://rules-python.readthedocs.io/en/latest/changelog.html).

{#v2-4-2}
## [2.4.2] - 2026-10-10

[2.4.2]: https://github.com/bazel-contrib/rules_python/releases/tag/2.4.2

{#v2-4-2-fixed}
### Fixed
* (zipapp) Shared libraries that a {obj}`py_zipapp_binary` reaches through
  Bazel's `_solib` symlinks are stored as files again, instead of as symlinks to
  absolute paths in the build machine's output base that dangle wherever the
  zipapp runs.


{#v2-4-1}
## [2.4.1] - 2026-10-06

[2.4.1]: https://github.com/bazel-contrib/rules_python/releases/tag/2.4.1

{#v2-4-1-changed}
### Changed
* (toolchain) Updated default Python 3.15 runtime from `3.15.0rc2` to
  `3.15.0rc3`.


{#v2-4-0}
## [2.4.0] - 2026-09-22

[2.4.0]: https://github.com/bazel-contrib/rules_python/releases/tag/2.4.0

{#v2-4-0-changed}
### Changed
* (bootstrap) {obj}`sys.path` adds the Python runtime in runfiles instead
  of the underlying Bazel repository cache directory
  ([#4104](https://github.com/bazel-contrib/rules_python/pull/4104)).
* (gazelle) Deprecate the `requirements` argument of `gazelle_python_manifest`
  in favor of the format-agnostic `lockfiles` argument, which supports `uv.lock`.
* (toolchain) Updated default Python 3.15 runtime from `3.15.0a8` to `3.15.0rc1`
  ([#4122](https://github.com/bazel-contrib/rules_python/pull/4122)).
* (toolchain) Updated default Python 3.15 runtime from `3.15.0rc1` to
  `3.15.0rc2`.
* (toolchain) Updated the default Python toolchain version from `3.11` to `3.14`
  in {obj}`python.defaults`, {obj}`python_register_toolchains`, and
  {obj}`python_register_multi_toolchains`
  ([#4023](https://github.com/bazel-contrib/rules_python/pull/4023)).
* (toolchains) Shared `libpython*.so*` files are now excluded by default from
  hermetic Python runtime files for recognized Astral `python-build-standalone`
  builds (`20250517` and newer), which statically link `libpython` into the
  interpreter. Older, custom, or unrecognized runtimes retain them. Set
  `libpython = "include"` or `"exclude"` on {obj}`python.override`,
  {obj}`python.single_version_override`,
  {obj}`python.single_version_platform_override`, or
  {obj}`python_register_toolchains` to override this behavior
  ([#4165](https://github.com/bazel-contrib/rules_python/pull/4165)).

{#v2-4-0-fixed}
### Fixed
* Include the Python toolchain's static libraries when `current_py_cc_libs` is used
  as a dependency of `cc_shared_library`.
* (bzlmod) Fixed a type mismatch error when using {obj}`coverage_tool` with
  {obj}`python.single_version_platform_override`
  ([#2570](https://github.com/bazel-contrib/rules_python/issues/2570)).
* (precompile) Fixed handling of directory and `.pyc` file inputs in
  {obj}`srcs` when {obj}`precompile` is enabled on {obj}`py_library`,
  {obj}`py_binary`, and {obj}`py_test` targets
  ([#4113](https://github.com/bazel-contrib/rules_python/pull/4113)).
* (pypi) Fixed wheel RECORD file generation on Windows so that rewritten shebang
  scripts correctly include the `.bat` extension
  ([#4114](https://github.com/bazel-contrib/rules_python/pull/4114)).
* (pypi) Fixed {obj}`RECORD` file paths for extracted `.data` directory contents
  so that {obj}`importlib.metadata.files()` correctly locates installed
  distribution files ([#4025](https://github.com/bazel-contrib/rules_python/pull/4025)).
* (pypi) Venv mode now works on NixOS and no longer requires coreutils to process
  wheel scripts and RECORD files
  ([#4125](https://github.com/bazel-contrib/rules_python/pull/4125)).
* (rules) Fixed loading Python extension modules from paths longer than `MAX_PATH` on Windows.
* (runfiles) Updated {obj}`runfiles.Path` method signatures for Python 3.14
  typeshed compatibility and fixed {obj}`runfiles.Path.match` on Python 3.12+.
  ([#4023](https://github.com/bazel-contrib/rules_python/issues/4023))
* (stamping) The build data spawn action is now skipped when `--stamp=false` and,
  instead the metadata file is written at analysis time via `ctx.actions.write()`.
* (toolchain) Fixed a crash in {obj}`py_test` main validation
  ({obj}`validate_test_main`) on Windows: the interpreter used for the check
  couldn't find its DLLs or its stdlib once relocated
  ([#4079](https://github.com/bazel-contrib/rules_python/issues/4079)).
* (toolchain) Fixed a crash on Windows when precompiling is enabled:
  the precompiler's interpreter couldn't find its DLLs once relocated
  ([#4082](https://github.com/bazel-contrib/rules_python/issues/4082)).
* (zipapp) Reduced self-contained archive sizes by preserving Python executable
  symlinks instead of storing each alias as another copy of the interpreter, and
  by omitting shared `libpython` files from recognized statically linked Astral
  runtime builds.

{#v2-4-0-added}
### Added
* (pypi) `py.typed` files from wheels are now included in the `pyi_srcs` of the
  wheel's `py_library`, alongside `.pyi` files. The `py.typed` file of
  `//python/runfiles` is now included in its `pyi_srcs` as well.
* (runfiles) Added {obj}`Runfiles.CreateOrRaise` to return a `Runfiles` instance
  or raise an error if runfiles cannot be found.
* (uv) Added {obj}`directory` attribute to {obj}`lock` to support running `uv`
  commands within subdirectories when generating lock files. Defaults to the
  package directory, set it to `None` or `""` to set it to the root of the repo
  ([#4029](https://github.com/bazel-contrib/rules_python/issues/4029)).




{#v2-3-4}
## [2.3.4] - 2026-09-21

[2.3.4]: https://github.com/bazel-contrib/rules_python/releases/tag/2.3.4

{#v2-3-4-added}
### Added
* (toolchains) Added win32 (`i686-pc-windows-msvc`) Python runtimes for
  versions 3.9.25, 3.10.20, 3.11.15, 3.12.13, 3.13.13, and 3.14.4
  ([#4156](https://github.com/bazel-contrib/rules_python/pull/4156)).

{#v2-3-3}
## [2.3.3] - 2026-09-04

[2.3.3]: https://github.com/bazel-contrib/rules_python/releases/tag/2.3.3

{#v2-3-3-changed}
### Changed
* (publish): The twine packages are now configured for three major platforms.

{#v2-3-3-fixed}
### Fixed
* (gazelle) Fixed a regression from version 1.8.0 which broke module map
  generation for old-style namespace packages.
  ([#4135](https://github.com/bazel-contrib/rules_python/pull/4135)).
* (zipapp) Fixed handling of {obj}`PyRuntimeInfo` with `files = None` so creating
  zipapp archives does not error.

{#v2-3-2}
## [2.3.2] - 2026-08-22

[2.3.2]: https://github.com/bazel-contrib/rules_python/releases/tag/2.3.2

{#v2-3-2-fixed}
### Fixed
* (pypi) Fixed analysis failures in {obj}`pip.parse` for source-less wheels with
  dependencies. ([#4053](https://github.com/bazel-contrib/rules_python/issues/4053))
* (pypi) Fixed the handling of optional args for the {obj}`pip_archive` and {obj}`whl_archive`
  repository rules within the {obj}`whl_library`. From now on we are dropping unsupported args.
* (pypi) Fixed {obj}`pip.parse` repository names for Git sources in `uv.lock`
  files by excluding URL query and fragment components
  ([#4084](https://github.com/bazel-contrib/rules_python/issues/4084)).

{#v2-3-1}
## [2.3.1] - 2026-08-14

[2.3.1]: https://github.com/bazel-contrib/rules_python/releases/tag/2.3.1

{#v2-3-1-fixed}
### Fixed
* Previous refactor that shipped with 2.3 introduced regression for the
  experimental repository cache users. This restores the previous behavior
  ([#3791](https://github.com/bazel-contrib/rules_python/pull/3791)).


{#v2-3-0}
## [2.3.0] - 2026-08-07

[2.3.0]: https://github.com/bazel-contrib/rules_python/releases/tag/2.3.0

{#v2-3-0-changed}
### Changed
* (gazelle) **BREAKING** rules_python 1.5.0 or higher is now required. The Python
  extension selects its standard library list on `is_python_3.14`, which earlier
  versions do not define.

{#v2-3-0-fixed}
### Fixed
* Fixed `py_binary_rule_builder()` / `py_test_rule_builder()` (from `python/api/executables.bzl`)
  failing at analysis time with a visibility error when used to construct a custom rule from an
  external module.
* (compile_pip_requirements) Add the explicit `data` attribute and forward it
  directly to the generated `py_binary`, so files passed via `data` can be
  referenced from `extra_args` using `$(location ...)`.
* (coverage) The warning about a missing bundled `coverage.py` wheel is no longer
  emitted as we are now falling back to a pure python wheel
  ([#3950](https://github.com/bazel-contrib/rules_python/issues/3950)).
* (gazelle) The Python extension now uses the correct standard library module list for
  `python_version` 3.13 and 3.14; previously both fell back to the 3.11 list, so modules
  added or removed since then (e.g. `compression.zstd`, `telnetlib`) were misclassified. The
  fallback list for unrecognized versions is now the newest available one rather than 3.11
  ([#3978](https://github.com/bazel-contrib/rules_python/pull/3978)).
* (pypi) Allow `uv_lock` to be specified in `pip.parse` without requiring
  `requirements_lock` (or other os-specific requirement file attributes) to be
  set.
* (pypi) Fixed the fixed-point loop that resolves self-referencing extras
  (`pkg[extra]` entries in a package's own `Requires-Dist`). The loop compared
  the number of extras discovered in the current round against the number known
  before it, rather than against the size of the merged set. As a result it
  could stop before every extra was resolved, silently dropping dependencies
  only reachable through two or more `pkg[extra]` hops, and for the common case
  of a package with no self-referencing extras it never converged at all,
  running all 10000 rounds while evaluating each wheel's generated `BUILD` file
  ([#4039](https://github.com/bazel-contrib/rules_python/pull/4039)).
* (pypi) Requirement `--hash=<algo>:<digest>` pins and Simple API
  `#<algo>=<digest>` URL fragments are now parsed for all hash algorithms
  instead of silently dropping everything except `sha256`. Non-sha256 pins are
  matched against the digests advertised by the index and downloads are verified
  using the corresponding Subresource Integrity value, and the pins are kept in
  the requirement line when falling back to `pip`
  ([#3972](https://github.com/bazel-contrib/rules_python/issues/3972)).
  As part of this, `whl_library` repos created by `pip.parse` now always pass
  the digest via the `integrity` attribute (SRI format) instead of `sha256`,
  and the lock file facts store digests as `<algo>:<digest>` values (the facts
  version was bumped, so cached index information is refreshed once).
* (pypi) `pip.parse(uv_lock = ...)` no longer exposes uv workspace/root members
  that resolve to no wheel or sdist (e.g. `source = { virtual = "." }` or editable
  installs). Previously these source-less packages were added to the hub's
  `all_requirements` / `all_whl_requirements` with an alias to a subpackage that
  does not exist, breaking analysis for anything enumerating the full set such as
  `modules_mapping(wheels = all_whl_requirements)`
  ([#3934](https://github.com/bazel-contrib/rules_python/issues/3934)).
* (pypi) correctly parse the `index_url` for each wheel so that the source registry is forwarded to
  the {obj}`whl_library`. This is so that the `purl` for `package_metadata` can be correctly
  constructed.
* (pypi) fixed the URL normalization function to correctly handle local paths
  enabling wheel sources files to point to an absolute path. Currently it supports
  the `file://<absolute_path>` for linux and windows like paths. We also support
  envsubst for the said paths from now on.

{#v2-3-0-added}
### Added
* (bzlmod) Added MODULE.bazel flag aliases for Starlark-defined flags:
  `build_python_zip`, `incompatible_default_to_explicit_init_py`,
  `python_path`, and `experimental_python_import_all_repositories`.
* (bzlmod) Added the `{obj}`explicit_init_py`` tag class to the
  `{obj}`config`` module extension for configuring implicit `__init__.py` file
  generation module-wide.
  ([#3997](https://github.com/bazel-contrib/rules_python/pull/3997),
  [#2945](https://github.com/bazel-contrib/rules_python/issues/2945))
* (cc) Added experimental {obj}`py_extension` macro for creating C/C++ Python
  extension modules
  ([#3283](https://github.com/bazel-contrib/rules_python/issues/3283)).
  (cc) Added `libc`, `platform_machine`, `platform_tag`, `soabi`, and
  `sys_platform` attributes and info fields to {obj}`py_cc_toolchain` /
  {obj}`PyCcToolchainInfo`.
* (pip,python) Added `pyproject_toml` attribute to {obj}`pip.default`, {obj}`pip.parse` and {obj}`python.defaults` to read the default Python version from the `requires-python` field of `pyproject.toml`.
* (py_test) Added an opt-in safeguard against `py_test` targets that silently
  pass without running any tests. Set
  {obj}`--@rules_python//python/config_settings:validate_test_main=enabled` to
  fail the build when a test's main module only contains inert top-level
  statements (definitions, imports, assignments) and never invokes a test
  runner ([#3824](https://github.com/bazel-contrib/rules_python/issues/3824)).


{#v2-2-0}
## [2.2.0] - 2026-06-30

[2.2.0]: https://github.com/bazel-contrib/rules_python/releases/tag/2.2.0

{#v2-2-0-changed}
### Changed
* Renamed most public bzl_library targets from `{foo}_bzl` to `{foo}` to follow
gazelle naming conventions. Deprecated aliases are left for backwards
compatibility.
* (binaries/tests) Added a deprecation warning for targets relying on implicit `__init__.py` creation.

{#v2-2-0-fixed}
### Fixed
* Fixed a flaky error on Windows 2022 when looking up the win32 version during
site initialization by retrying the lookup
([#3721](https://github.com/bazel-contrib/rules_python/issues/3721)).
* (binaries) Fixed building of legacy zipapps on Windows execution platforms by
  using a hermetic tool instead of host `cat`.
* (bootstrap) Fixed stage 1 bootstrap imports when target outputs shadow
  standard library modules.
* (coverage) Skip lcov report when no data was collected.
* (pypi) Fixed `experimental_index_url` checking truthiness before envsubst
expansion.
* (rules) Fixed venv output paths for `py_binary` and `py_test` targets whose
names contain path separators so distinct targets with the same basename no
longer share the same venv output directory.
* (windows) Fixed build data generation on localized Windows installations.

{#v2-2-0-added}
### Added
* Added {bzl:obj}`features.loadable_symbols` to allow detecting public symbols
exported by bzl files.
* Exposed {bzl:obj}`VenvSymlinkEntry` and {bzl:obj}`VenvSymlinkKind` in
{bzl:target}`//python:py_info.bzl`.
* (pypi) Added `@pypi` repo: a unified hub of `pip.parse` hubs.
* (pypi) Added a `dep` tag class to the `pip` bzlmod extension. This allows
  modules to declare abstract PyPI dependencies, ensuring target structures
  exist in the unified hub, while allowing other modules to provide the
  concrete implementation via `pip.parse`.
* (uv) Support for basic `uv.lock` generation via the `lock` rule
and basic support for importing the `uv.lock` file itself. Since this
may have bugs, please report this by creating new tickets.
Work towards [#2787](https://github.com/bazel-contrib/rules_python/issues/2787)
and [#1975](https://github.com/bazel-contrib/rules_python/issues/1975).



{#v2-1-0}
## [2.1.0] - 2026-06-17

[2.1.0]: https://github.com/bazel-contrib/rules_python/releases/tag/2.1.0

{#v2-1-0-removed}
### Removed
* (build_data) Removed CONFIG_MODE from build data
  ([#3793](https://github.com/bazel-contrib/rules_python/issues/3793)).
* (coverage) Support for python 3.8 has been dropped from the bundled
  `coverage.py` wheel set, since coverage.py 7.6.2 dropped it.

{#v2-1-0-changed}
### Changed
* (bzlmod) How default runtimes are registered has changed to use a manifest
  of SHAs and URLs. `TOOL_VERSIONS` in `python/versions.bzl` is now empty under
  bzlmod.
* (gazelle) WORKSPACE's bazel-gazelle dependency bumped from 0.36.0 to 0.47.0.
  The go version was also bumped from 1.21.13 to 1.22.9.
* (gazelle) `python_generate_pyi_deps` and `python_generate_pyi_srcs` now
  default to `true`.
* (pypi) The data files of a wheel (bin, includes, etc) are now always included
  as a library's data dependencies.
* (coverage) When `configure_coverage_tool = True` is set but the bundled
  `coverage.py` wheel set has no entry for the requested python version and
  platform, a warning is now printed instead of silently producing an empty
  coverage report.

{#v2-1-0-fixed}
### Fixed
* (gazelle) `py_library` and `py_test` targets with missing source files can now be
  removed by Gazelle ([#3375](https://github.com/bazel-contrib/rules_python/issues/3375)). 
  However `map_kind` and `alias_kind` will not be removed unless people are running a 
  gazelle version that includes 
  [bazel-gazelle#2362](https://github.com/bazel-contrib/bazel-gazelle/pull/2362)
* (bootstrap) Fixed a potential race condition with symlink creation during
  startup.
* (gazelle) Fixed handling of auto-included `__init__.py` files when generating `py_binary`
  targets ([#3729](https://github.com/bazel-contrib/rules_python/issues/3729)).
* (entry_point) From now on `mypy` type checking will be skipped on the generated
  files ([#3126](https://github.com/bazel-contrib/rules_python/issues/3126)).
* (pypi) Support `--experimental_isolated_extension_usages`
  ([#3668](https://github.com/bazel-contrib/rules_python/issues/3668)).
* (uv) use the astral.sh mirror as the preferred url for binary downloads,
  with github.com as a fallback; for uv >= 0.11.0, read the checksums directly
  from the dist-manifest contents.
* (pypi) Fix `importlib.metadata.files` by ensuring `RECORD` is included in
  installed wheel targets, except when built from sdist
  ([#3024](https://github.com/bazel-contrib/rules_python/issues/3024)).
* (system_python) Fix AttributeError exception on Debian 10 Buster
  python installations which may not set `sys._base_executable`
  ([#3774](https://github.com/bazel-contrib/rules_python/issues/3774)).
* (windows) Fix `py_test`/`py_binary` failure when the target name contains
  path separators; the bootstrap stub is now declared as a sibling of the
  `.exe` launcher
  ([#3789](https://github.com/bazel-contrib/rules_python/issues/3789)).
* Fix the forwarding of `target_compatible_with` from `compile_pip_requirements`
  towards the underlying `*.update` target.
  ([#3787](https://github.com/bazel-contrib/rules_python/pull/3787))
* (uv) allow user overwrite the build environment using `--action_env` to allow
  setting authentication for the index URL.
  ([#3405](https://github.com/bazel-contrib/rules_python/issues/3405))
* (uv) fix the execution of the `uv pip compile` in the sandbox. Work
  towards better supporting `uv` out of the box on our platforms.
  ([#1975](https://github.com/bazel-contrib/rules_python/issues/1975))
* (uv) automatically pass the `--project` parameter based on the source files.
  ([#3087](https://github.com/bazel-contrib/rules_python/issues/3087))
* (coverage) handle nested coverage collection
  ([#3823](https://github.com/bazel-contrib/rules_python/pull/3823))

{#v2-1-0-added}
### Added
* (toolchain) Added {obj}`PyRuntimeInfo.interpreter_files_to_run` so action
  consumers can execute an in-build runtime interpreter with its runfiles.
* (toolchains) Support dynamically fetching and registering Python runtimes
  from a python-build-standalone manifest file using
  `python.override(add_runtime_manifest_urls = ..., runtime_manifest_sha = ...)`.
* (toolchain) Added {obj}`python.override.toolchain_target_settings` to allow
  adding `config_setting` labels to all registered toolchains.
* (windows) Full venv support for Windows is available. Set
  {obj}`--venvs_site_packages=yes` to enable.
* (test/binaries) When {obj}`--venv_site_packages=yes` is enabled,
  wheel `data`, `bin`, and `include` files are populated into the venv.
* (runfiles) Added a pathlib-compatible API: {obj}`Runfiles.root()`
  Fixes [#3296](https://github.com/bazel-contrib/rules_python/issues/3296).
* (gazelle) Support alias_kind directive.
  Fixes [#3183](https://github.com/bazel-contrib/rules_python/issues/3183).
* (pypi) `package_metadata` support, fixes 
  [#2054](https://github.com/bazel-contrib/rules_python/issues/2054).
* (coverage) Add support for python 3.14 and bump `coverage.py` to 7.10.7.


{#v2-0-3}
## [2.0.3] - 2026-06-15

[2.0.3]: https://github.com/bazel-contrib/rules_python/releases/tag/2.0.3

{#v2-0-3-fixed}
### Fixed
* (pypi) Assume that all of the packages are available on a particular hub if
  there is only a single PyPI compatible index to be used. This saves us an expensive
  PyPI download and supports PyPI mirror implementations that do not support the root
  index functionality. Fixes [#3769](https://github.com/bazel-contrib/rules_python/pull/3769).

{#v2-0-2}
## [2.0.2] - 2026-05-14

[2.0.2]: https://github.com/bazel-contrib/rules_python/releases/tag/2.0.2

{#v2-0-2-added}
### Added
* (toolchains) `3.13.12`, `3.14.3` Python toolchain from [20260325] release.
* (toolchains) `3.10.20`, `3.11.15`, `3.12.13`, `3.13.13` `3.14.4`, `3.15.0a8`
* Python toolchain from [20260414] release.

[20260325]: https://github.com/astral-sh/python-build-standalone/releases/tag/20260325
[20260414]: https://github.com/astral-sh/python-build-standalone/releases/tag/20260414

{#v2-0-1}
## [2.0.1] - 2026-05-08

[2.0.1]: https://github.com/bazel-contrib/rules_python/releases/tag/2.0.1

{#v2-0-1-fixed}
### Fixed

* (pypi) Fix the versions of packages that we are recording to a `MODULE.bazel.lock` file
  facts by passing all of the versions to the `get_index` function.
  Fixes [#3756](https://github.com/bazel-contrib/rules_python/issues/3756).
* (bzlmod) Reduce default verbosity of our loggers for non-root modules
  ([#3749](https://github.com/bazel-contrib/rules_python/issues/3749)).

{#v2-0-0}
## [2.0.0] - 2026-04-09

[2.0.0]: https://github.com/bazel-contrib/rules_python/releases/tag/2.0.0

{#v2-0-0-removed}
### Removed
* Nothing removed.

{#v2-0-0-changed}
### Changed

**Breaking**
* {obj}`--windows_enable_symlinks` is required. Add `startup
  --windows_enable_symlinks` to your `.bazelrc` to enable Bazel using full
  symlink support on Windows.
* venv-based binaries are created by default ({obj}`--bootstrap_impl=system_python`)
  on supported platforms (Linux/Mac with Bazel 8+, or Windows).
* `--build_python_zip` on Windows is ignored. Use {obj}`py_zipapp_binary` to create
  zips of Python programs.
* (pypi) Previously `experimental_index_url` users would not need to specify
  target platforms if cross-building is required. From now we will only pull
  wheels for the host OS to better align with how the rules work with the legacy
  `pip` implementation. Use {obj}`pip.parse.target_platforms` to customize the
  behavior.
  Related to [#260](https://github.com/bazel-contrib/rules_python/issues/260).

Other changes:
* (pypi) Update dependencies used for `compile_pip_requirements`, building
  sdists in the `whl_library` rule and fetching wheels using `pip`.
* (pypi) Before using the bazel downloader to fetch the PyPI package metadata
  we will from now on fetch the lists of available packages on each index. The
  used package mappings will be written as facts to the `MODULE.bazel.lock` file
  on supported bazel versions and it should be done at most once. As a result,
  per-package {obj}`experimental_index_url_overrides` is no longer needed, but
  if specified, it needs to be provided for all packages not on the default index. What
  is more, the flags for `--index_url` and `--extra-index-url` now behave in the
  same way as in `uv` or `pip`, i.e. we default to `--index-url` if the package
  is not found in `--extra-index-url`.  Fixes
  ([#3260](https://github.com/bazel-contrib/rules_python/issues/3260) and
  [#2632](https://github.com/bazel-contrib/rules_python/issues/2632)).
* (uv) We will now use the download URL specified in the `uv`'s
 `dist_manifest.json` file. If you have redirects or blocking rules as part of
  your downloader setup, you may need to adjust them. What is more, the default
  uv version has been bumped `0.11.2`.
* (runfiles): Type annotations are no longer tested for Python 3.9.
* Windows no longer defaults to creating a zip file and extracting it; a
  symlink-based runfiles tree is created, as on unix-like platforms.

{#v2-0-0-fixed}
### Fixed
* (toolchain) Also set Make variables for local toolchains.
* (zipapp) Resolve issue passing through compression settings in
  `py_zippapp_binary` targets
  ([#3646](https://github.com/bazel-contrib/rules_python/issues/3646)).
* (toolchains) The pyc created at runtime in the stdlib should no longer
  cause the Python runtime repository to be invalidated. The stdlib pyc files
  _may_ be reused in between invocations, depending upon the sandboxing
  configuration. See the {any}`RULES_PYTHON_PYCACHE_DIR` environment variable
  for more information.
  ([#3643](https://github.com/bazel-contrib/rules_python/issues/3643)).
* (bootstrap) Fixed incorrect runfiles path construction in bootstrap
  scripts when binary is defined in another bazel module
  ([#3563](https://github.com/bazel-contrib/rules_python/issues/3563)).
* (bootstrap) Resolve `RUNFILES_DIR` inheritance issues, which lead to a child
  Python binary incorrectly using it's parent's Python binary environment
  ([#3518](https://github.com/bazel-contrib/rules_python/issues/3518)).
* (uv) Downloads for versions `>=0.10` work again. In order to fix this we had
  drop support for `powerpc64` platform. People interested in the platform can
  bring it back via the `uv.default` API. Like:
  ```
  uv.default(
      compatible_with = [
          "@platforms//os:linux",
          "@platforms//cpu:ppc",
      ],
      platform = "powerpc64-unknown-linux-gnu",
  )
  ```
  Fixes [#3676](https://github.com/bazel-contrib/rules_python/issues/3676).
* (pypi) Fixes wheel extraction on hosts without python installed,
  Fixes [#3712](https://github.com/bazel-contrib/rules_python/issues/3712).

{#v2-0-0-added}
### Added
* (pypi) Write SimpleAPI contents to the `MODULE.bazel.lock` file if using
  {obj}`experimental_index_url` which should speed up consecutive
  initializations and should no longer require the network access if the cache is
  hydrated.  Implements
  [#2731](https://github.com/bazel-contrib/rules_python/issues/2731).
* (pypi) The `--index-url` and `--extra-index-url` is now parsed from the lock
  file and the {obj}`pip.parse.experimental_index_url` and
  {obj}`pip.parse.experimental_extra_index_urls` is
  no longer mandatory to leverage the bazel downloader.
  Implements
  [#1357](https://github.com/bazel-contrib/rules_python/issues/1357),
  [#2951](https://github.com/bazel-contrib/rules_python/issues/2951).
* (pypi) If cross-compilation is needed, use the {obj}`pip.parse.target_platforms`
  to specify exactly which platforms should be supported.
  Implements
  [#260](https://github.com/bazel-contrib/rules_python/issues/260).
* (wheel) Specifying a path ending in `/` as a destination in `data_files`
  will now install file(s) to a folder, preserving their basename.
* Various attributes and fields added to support venvs on Windows:
  * {obj}`py_runtime.venv_bin_files` and {obj}`PyRuntime.venv_binfiles`
    field added to specify additional Python runtime files Windows needs for
    venvs.
  * {obj}`PyExecutableInfo.venv_interpreter_runfiles`, and
    {obj}`PyExecutableInfo.venv_interpreter_symlinks` adde
* (wheel) Add support for `add_path_prefix` argument in `py_wheel` which can be
  used to prepend a prefix to the files in the wheel.

{#v1-9-1}
## [1.9.1] - 2026-05-14

[1.9.1]: https://github.com/bazel-contrib/rules_python/releases/tag/1.9.1

{#v1-9-1-added}
### Added
* (toolchains) `3.13.12`, `3.14.3` Python toolchain from [20260325] release.
* (toolchains) `3.10.20`, `3.11.15`, `3.12.13`, `3.13.13` `3.14.4`, `3.15.0a8`
* Python toolchain from [20260414] release.

{#v1-9-0}
## [1.9.0] - 2026-02-21

[1.9.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.9.0

{#v1-9-0-removed}
### Removed
* Nothing removed.

{#v1-9-0-changed}
### Changed
* **DEPRECATED: implicit zipapp support**
  * Implicit zipapp output of `py_binary`/`py_test` has been deprecated and
    replaced by separate {obj}`py_zipapp_binary` and {obj}`py_zipapp_test`
    rules. See
    [#3567](https://github.com/bazel-contrib/rules_python/issues/3567)
    for a detailed migration guide.
* (toolchains) stop exposing config settings in python toolchain alias repos.
  Please consider depending on the flags defined in
  `//python/config_setting/...` and the `@platforms` package instead.
* (binaries/tests) The `PYTHONBREAKPOINT` environment variable is automatically inherited
* (binaries/tests) The {obj}`stamp` attribute now transitions the Bazel builtin
  {flag}`--stamp` flag.
* (pypi) Now the RECORD file patches will follow the quoted or unquoted filenames convention
  in order to make `pytorch` and friends easier to patch.
* (wheel) `py_wheel` no longer expands the input depset during analysis,
  improving analysis performance for targets with large dependency trees.
* (binaries/tests) (Windows) `--enable_runfiles=true` is the default for
  `py_binary/py_test`. Prior behavior can be restored by adding
  `@rules_python//command_line_option:enable_runfiles=false` or
  `@rules_python//command_line_option:enable_runfiles=INHERIT` to the
  `config_settings` attribute. NOTE: `enable_runfiles=true` will
  soon become **required for Windows**.

{#v1-9-0-fixed}
### Fixed
* (tests) No more coverage warnings are being printed if there are no sources.
  ([#2762](https://github.com/bazel-contrib/rules_python/issues/2762))
* (gazelle) Ancestor `conftest.py` files are added in addition to sibling `conftest.py`.
  ([#3497](https://github.com/bazel-contrib/rules_python/issues/3497)) Note
  that this behavior can be reverted to the pre-1.9.0 behavior by setting the new
  `python_include_ancestor_conftest` directive to `false`.
* (binaries/tests) Stamped build data generated by Windows actions is readable

{#v1-9-0-added}
### Added
* (binaries/tests) {obj}`--debugger`: allows specifying an extra dependency
  to add to binaries/tests for custom debuggers.
* (binaries/tests) Build information is now included in binaries and tests.
  Use the `bazel_binary_info` module to access it. The {flag}`--stamp` flag will
  add {obj}`--workspace_status_command` information.
* (gazelle) A new directive `python_generate_pyi_srcs` has been added. When
  `true`, a `py_*` target's `pyi_srcs` attribute will be set if any `.pyi` files
  that are associated with the target's `srcs` are present.
  ([#3354](https://github.com/bazel-contrib/rules_python/issues/3354)).
* (zipapp) {obj}`py_zipapp_binary` and {obj}`py_zipapp_test` rules added. These
  will replace `--build_python_zip` and the zip output group of
  `py_binary/py_test`. The zipapp rules support more functionality, correctness,
  and have better build performance.
* (toolchains) Added {obj}`PyExecToolsInfo.exec_runtime` for more easily
  getting an RBE-compatible runtime to use for build actions.
* (providers) {obj}`PyExecutableInfo` has several new fields to aid packaging
  of binaries: {obj}`PyExecutableInfo.app_runfiles`,
  {obj}`PyExecutableInfo.interpreter_args`,
  {obj}`PyExecutableInfo.stage2_bootstrap`, and
  {obj}`PyExecutableInfo.venv_python_exe`.
* (tools/wheelmaker.py) Added support for URL requirements according to PEP 508
  in Requires-Dist metadata. ([#3569](https://github.com/bazel-contrib/rules_python/pull/3569))
* (gazelle) A new directive `python_include_ancestor_conftest` has been added.
  When `false`, ancestor `conftest` targets are not automatically added to
  {bzl:obj}`py_test` target dependencies. This `false` behavior is how things
  were in `rules_python` before 1.9.0. The default is `true`, as the prior behavior
  was technically incorrect.
  ([#3596](https://github.com/bazel-contrib/rules_python/pull/3596))


{#v1-8-5}
## [1.8.5] - 2026-02-22

[1.8.5]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.5

{#v1-8-5-fixed}
### Fixed
* (runfiles) Fixed `CurrentRepository()` raising `ValueError` on Windows.
  ([#3579](https://github.com/bazel-contrib/rules_python/issues/3579))
* (pypi) `pip_parse` no longer silently drops PEP 508 URL-based requirements
  (`pkg @ https://...`) when `extract_url_srcs=False` (the default for
  `pip_repository`).
* (pypi) Extras in requirement strings are now normalized per PEP 685,
  fixing missing transitive dependencies when extras contain hyphens
  (e.g., `sqlalchemy[postgresql-psycopg2binary]`).
  ([#3587](https://github.com/bazel-contrib/rules_python/issues/3587))

{#v1-8-4}
## [1.8.4] - 2026-02-10

[1.8.4]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.4

{#v1-8-4-fixed}
### Fixed
* (pipstar): A corner case of evaluation of version specifiers (`"1.2" ~= "1.2.0"`)
  has been fixed improving compatibility with the PEP440 standard.
  Fixes [#3580](https://github.com/bazel-contrib/rules_python/issues/3580).
* (pipstar): We now add read permissions after extracting wheels for the cases
  where the `whl` file is missing them.
  Fixes [#3554](https://github.com/bazel-contrib/rules_python/issues/3554).

{#v1-8-3}
## [1.8.3] - 2026-01-27

[1.8.3]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.3

{#v1-8-3-fixed}
### Fixed
* (pipstar) Fix whl extraction on Windows when bazelrc has XX flags.
  Fixes [#3543](https://github.com/bazel-contrib/rules_python/issues/3543).

{#v1-8-2}
## [1.8.2] - 2026-01-24

[1.8.2]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.2

{#v1-8-2-fixed}
### Fixed
* (venvs) relax the C library filename check to make tensorflow work
  Fixes [#3524](https://github.com/bazel-contrib/rules_python/issues/3529).

{#v1-8-1}
## [1.8.1] - 2026-01-20

[1.8.1]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.1

{#v1-8-1-fixed}
### Fixed
* (pipstar) Extra resolution that refers back to the package being resolved works again.
  Fixes [#3524](https://github.com/bazel-contrib/rules_python/issues/3524).

{#v1-8-0}
## [1.8.0] - 2025-12-19

[1.8.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.8.0

{#v1-8-0-known-issues}
### Known Issues
* (gazelle) Windows support for the Gazelle plugin may be broken. See
  [#3416](https://github.com/bazel-contrib/rules_python/issues/3416) for
  details and possible workarounds.

{#v1-8-0-removed}
### Removed
* (toolchain) Remove all of the python 3.8 toolchain support out of the box. Users need
  to pass the `TOOL_VERSIONS` that include 3.8 toolchains or use the `bzlmod` APIs to add
  them back. This means any hub `pip.parse` calls that target `3.8` will be ignored from
  now on. ([#2704](https://github.com/bazel-contrib/rules_python/issues/2704))
  {bzl:obj}`python.single_version_override`, like:

  ```starlark
  python = use_extension("@rules_python//python/extensions:python.bzl", "python")

  python.single_version_override(
      python_version = "3.8.20",
      sha256 = {
          "aarch64-apple-darwin": "2ddfc04bdb3e240f30fb782fa1deec6323799d0e857e0b63fa299218658fd3d4",
          "aarch64-unknown-linux-gnu": "9d8798f9e79e0fc0f36fcb95bfa28a1023407d51a8ea5944b4da711f1f75f1ed",
          "x86_64-apple-darwin": "68d060cd373255d2ca5b8b3441363d5aa7cc45b0c11bbccf52b1717c2b5aa8bb",
          "x86_64-pc-windows-msvc": "41b6709fec9c56419b7de1940d1f87fa62045aff81734480672dcb807eedc47e",
          "x86_64-unknown-linux-gnu": "285e141c36f88b2e9357654c5f77d1f8fb29cc25132698fe35bb30d787f38e87",
      },
      urls = ["https://github.com/astral-sh/python-build-standalone/releases/download/20241002/cpython-{python_version}+20241002-{platform}-{build}.tar.gz"],
  )
  ```
* (toolchain) Remove all of the python 3.9 toolchain versions except for the `3.9.25`.
  This version has reached EOL and will no longer receive any security fixes, please update to
  `3.10` or above. ([#2704](https://github.com/bazel-contrib/rules_python/issues/2704))
* (toolchain) `ignore_root_user_error` has now been flipped to be always enabled and
  the `chmod` of the python toolchain directories have been removed. From now on `rules_python`
  always adds the `pyc` files to the glob excludes and in order to avoid any problems when using
  the toolchains in the repository phase, ensure that you pass `-B` to the python interpreter.
  ([#2016](https://github.com/bazel-contrib/rules_python/issues/2016))

{#v1-8-0-changed}
### Changed
* (toolchains) Use toolchains from the [20251031] release.
* (gazelle) Internally split modules mapping generation to be per-wheel for concurrency and caching.
* (pip) `pipstar` has been enabled for all `whl_library` instances where the whl
  is passed through a label or downloaded using the bazel downloader
  ([#2949](https://github.com/bazel-contrib/rules_python/issues/2949)).
* (pypi) `pipstar` flag default has been flipped to be on by default.
  It can be disabled through `RULES_PYTHON_ENABLE_PIPSTAR=0` environment variable.
  If you do need to disable it, please add a comment to
  [#2949](https://github.com/bazel-contrib/rules_python/issues/2949).
* (gazelle deps) rules_go bumped from 0.55.1 to 0.59.0
* (gazelle deps) gazelle bumped from 0.36.0 to 0.47.0

{#v1-8-0-fixed}
### Fixed
* (gazelle) Remove {obj}`py_binary` targets with invalid `srcs`. This includes files
  that are not generated or regular files.
  [#3046](https://github.com/bazel-contrib/rules_python/pull/3046)
* (runfiles) Fix incorrect Python runfiles path assumption - the existing
  implementation assumes that it is always four levels below the runfiles
  directory, leading to incorrect path checks
  ([#3085](https://github.com/bazel-contrib/rules_python/issues/3085)).
* (toolchains) local toolchains now tell the `sys.abiflags` value of the
  underlying runtime.
* (toolchains) various local toolchain fixes: add abi3 header targets,
  fixes to linking, Windows DLL detection, and defines for free threaded
  runtimes.
* (toolchains) The `python_headers` target is now compatible with
  layering_check.
* (performance) 90% reduction in py_binary/py_test analysis phase cost.
  ([#3381](https://github.com/bazel-contrib/rules_python/pull/3381)).
* (gazelle) Fix `gazelle_python_manifest.test` so that it accesses manifest files via `runfile` path handling rather than directly ([#3397](https://github.com/bazel-contrib/rules_python/issues/3397)).
* (core rules) For the system_python bootstrap, the runfiles root is added to
  sys.path.
* (sphinxdocs) The sphinxdocs `.serve` target is now compatible with Bazel's `--symlink_prefix`
  flag ([#3410](https://github.com/bazel-contrib/rules_python/issues/3410)).

{#v1-8-0-added}
### Added
* (toolchains) `3.9.25` Python toolchain from [20251031] release.
* (toolchains) `3.13.10`, `3.14.1` Python toolchain from [20251202] release.
* (toolchains) `3.13.11`, `3.14.2`, `3.15.0a2` Python toolchains from [20251209] release.
* (pypi) API to tell `pip.parse` which platforms users care about. This is very useful to  ensure
  that when users do `bazel query` for their deps, they don't have to download all of the
  dependencies for all of the available wheels. Torch wheels can be up of 1GB and it takes a lot
  of time to download those, which is unnecessary if only the host platform builds are necessary
  to be performed. This is mainly for backwards/forwards compatibility whilst rolling out
  `RULES_PYTHON_ENABLE_PIPSTAR=1` by default. Users of `experimental_index_url` that perform
  cross-builds should add {obj}`target_platforms` to their `pip.parse` invocations, which will
  become mandatory if any cross-builds are required from the next release.
* (py_library) Attribute {obj}`namespace_package_files` added. It is a hint for
  optimizing venv creation.

[20251031]: https://github.com/astral-sh/python-build-standalone/releases/tag/20251031
[20251202]: https://github.com/astral-sh/python-build-standalone/releases/tag/20251202
[20251209]: https://github.com/astral-sh/python-build-standalone/releases/tag/20251209

{#v1-7-0}
## [1.7.0] - 2025-10-11

[1.7.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.7.0

{#v1-7-0-removed}
### Removed
* (core rules) Support for Bazel's long deprecated "extra actions" has been
  removed
  ([#3215](https://github.com/bazel-contrib/rules_python/issues/3215)).

{#v1-7-0-changed}
### Changed
* (deps) bumped rules_cc dependency to `0.1.5`.
* (bootstrap) For {obj}`--bootstrap_impl=system_python`, `PYTHONPATH` is no
  longer used to add import paths. The sys.path order has changed from
  `[app paths, stdlib, runtime site-packages]` to `[stdlib, app paths, runtime
  site-packages]`.
* (bootstrap) For {obj}`--bootstrap_impl=system_python`, the sys.path order has
  changed from `[app paths, stdlib, runtime site-packages]` to `[stdlib, app
  paths, runtime site-packages]`.
* (pip) Publishing deps are no longer pulled via `experimental_index_url`.
  ([#2937](https://github.com/bazel-contrib/rules_python/issues/2937)).
* (toolchains) `py_runtime` and `PyRuntimeInfo` reject Python 2 settings.
  Setting `py_runtime.python_version = "PY2"` or non-None
  `PyRuntimeInfo.py2_runtime` is an error.
* (pypi) `pipstar` flag has been implemented for `WORKSPACE` and can be flipped to be enabled using `RULES_PYTHON_ENABLE_PIPSTAR=1` environment variable. If you do, please
  add a comment to
  [#2949](https://github.com/bazel-contrib/rules_python/issues/2949) if you run into any
  problems.
  With this release we are deprecating {obj}`pip.parse.experimental_target_platforms` and
  `pip_repository.experimental_target_platforms`. For users using `WORKSPACE` and
  vendoring the `requirements.bzl` file, please re-vendor so that downstream is unaffected
  when the APIs get removed. If you need to customize the way the dependencies get
  evaluated, see [our docs](https://rules-python.readthedocs.io/en/latest/pypi/download.html#customizing-requires-dist-resolution) on customizing `Requires-Dist` resolution.
* (toolchains) Added Python versions 3.15.0a1, 3.14.0, 3.13.9, 3.12.12, 3.11.14, 3.10.19, and 3.9.24
  from the [20251014] release.
* (deps) (bzlmod) Upgraded to `bazel-skylib` version
  [1.8.2](https://github.com/bazelbuild/bazel-skylib/releases/tag/1.8.2)

[20251014]: https://github.com/astral-sh/python-build-standalone/releases/tag/20251014

{#v1-7-0-fixed}
### Fixed
* (rules) The `PyInfo` constructor was setting the wrong value for
  `has_py3_only_sources` - this is now fixed.
* (bootstrap) The stage1 bootstrap script now correctly handles nested `RUNFILES_DIR`
  environments, fixing issues where a `py_binary` calls another `py_binary`
  ([#3187](https://github.com/bazel-contrib/rules_python/issues/3187)).
* (bootstrap) For Windows, having many dependencies no longer results in max
  length errors due to too long environment variables.
* (bootstrap) {obj}`--bootstrap_impl=script` now supports the `-S` interpreter
  setting.
* (venvs) {obj}`--venvs_site_packages=yes` no longer errors when packages with
  overlapping files or directories are used together.
  ([#3204](https://github.com/bazel-contrib/rules_python/issues/3204)).
* (venvs) {obj}`--venvs_site_packages=yes` works for packages that dynamically
  link to shared libraries
  ([#3228](https://github.com/bazel-contrib/rules_python/issues/3228)).
* (venvs) {obj}`--venvs_site_packages=yes` includes `pth` files at the root of the
  site-packages folder
  ([#3339](https://github.com/bazel-contrib/rules_python/issues/3339)).
* (uv) {obj}`//python/uv:lock.bzl%lock` now works with a local platform
  runtime.
* (pypi) `linux_riscv64` is added to the platforms list in `_pip_repository_impl`,
  which fixes [a build issue for tensorflow on riscv64](https://github.com/bazel-contrib/rules_python/discussions/2729).
* (toolchains) WORKSPACE builds now correctly register musl and freethreaded
  variants. Setting {obj}`--py_linux_libc=musl` and `--py_freethreaded=yes` now
  activate them, respectively.
  ([#3262](https://github.com/bazel-contrib/rules_python/issues/3262)).
* (rules) {obj}`py_console_script_binary` is now compatible with symbolic macros
  ([#3195](https://github.com/bazel-contrib/rules_python/pull/3195)).

{#v1-7-0-added}
### Added
* (runfiles) The Python runfiles library now supports Bazel's
  `--incompatible_compact_repo_mapping_manifest` flag.
* (bootstrap) {obj}`--bootstrap_impl=system_python` now supports the
  {obj}`main_module` attribute.
* (bootstrap) {obj}`--bootstrap_impl=system_python` now supports the
  {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable.
* (rules) The `py_binary`, `py_test`, and `py_wheel` rules now have a
  {obj}`config_settings` attribute to control build flags within the build graph.
  Custom settings can be added using {obj}`config.add_transition_setting` in
  `MODULE.bazel` files, or {obj}`py_repositories(transition_settings=...)` in
  `WORKSPACE` files. See the
  {ref}`common-deps-with-multiple-pypi-versions` guide on using common
  dependencies with multiple PyPI versions` for an example.
* (toolchains) Stable ABI headers support added. To use, depend on
  {obj}`//python/cc:current_py_cc_headers_abi3`. This allows Windows builds
  a way to depend on headers without the potentially Python unstable ABI
  objects from the regular {obj}`//python/cc:current_py_cc_headers` target
  being included.
  * Adds {obj}`//python/cc:current_py_cc_headers_abi3`,
    {obj}`py_cc_toolchain.headers_abi3`, and {obj}`PyCcToolchainInfo.headers_abi3`.
  * {obj}`//python:features.bzl%features.headers_abi3` can be used to
    feature-detect the presense of the above.
* (toolchains) Local toolchains can use a label for the interpreter to use.
* (pypi) Support for environment marker handling and `experimental_index_url` handling for
  Windows ARM64 for Python 3.11 and later
  ([#2276](https://github.com/bazel-contrib/rules_python/issues/2276)).

{#v1-6-3}
## [1.6.3] - 2025-09-21

[1.6.3]: https://github.com/bazel-contrib/rules_python/releases/tag/1.6.3

{#v1-6-3-fixed}
### Fixed

* (pypi) We now use the Minimal Version Selection (MVS) algorithm to select
  the right wheel when there are multiple wheels for the target platform
  (e.g. `musllinux_1_1_x86_64` and `musllinux_1_2_x86_64`). If the user
  wants to set the minimum version for the selection algorithm, use the
  {obj}`pip.default.whl_platform_tags` attribute to configure that. If
  `musllinux_*_x86_64` is specified, we will choose the lowest available
  wheel version. Fixes [#3250](https://github.com/bazel-contrib/rules_python/issues/3250).

{#v1-6-0}
## [1.6.0] - 2025-08-23

[1.6.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.6.0

{#v1-6-0-changed}
### Changed
* (gazelle) update minimum gazelle version to 0.36.0 - may cause BUILD file changes
* (gazelle) update minimum rules_go version to 0.55.1
* (gazelle) remove custom go-tree-sitter module BUILD file
* (gazelle) For package mode, resolve dependencies when imports are relative
  to the package path. This is enabled via the
  `# gazelle:python_experimental_allow_relative_imports` true directive ({gh-issue}`2203`).
* (gazelle) Types for exposed members of `python.ParserOutput` are now all public.
* (gazelle) Removed the requirement for `__init__.py`, `__main__.py`, or `__test__.py` files to be
  present in a directory to generate a `BUILD.bazel` file.
* (toolchain) Updated the following toolchains to build [20250808] to patch CVE-2025-47273:
    * 3.9.23
    * 3.10.18
    * 3.11.13
    * 3.12.11
    * 3.14.0rc1
* (toolchain) Python 3.13 now references 3.13.6
* (gazelle) Switched back to smacker/go-tree-sitter, fixing
  [#2630](https://github.com/bazel-contrib/rules_python/issues/2630)
* (pypi) From now on the list of default platforms only includes `linux_x86_64`, `linux_aarch64`,
  `osx_x86_64`, `osx_aarch64` and `windows_x86_64`. If you are on other platforms, you need to
  use the `pip.default` to configure it yourself. If you are interested in graduating the
  platform, consider helping set us up CI for them and update the documentation.
* (ci) We are now testing on Ubuntu 22.04 for RBE and non-RBE configurations.
* (core) `#!/usr/bin/env bash` is now used as a shebang in the stage1 bootstrap template.
* (gazelle:docs) The Gazelle docs have been migrated from {gh-path}`gazelle/README.md` to
  {gh-path}`gazelle/docs` and are now available on the primary documentation site
  at <https://rules-python.readthedocs.io/en/latest/gazelle/docs/index.html>

[20250808]: https://github.com/astral-sh/python-build-standalone/releases/tag/20250808

{#v1-6-0-fixed}
### Fixed
* (toolchains) `local_runtime_repo` now respects changes to the `DEVELOPER_DIR` and `XCODE_VERSION`
  repo env vars, fixing stale cache issues on macOS with system (i.e. Xcode-supplied) Python
  ([#3123](https://github.com/bazel-contrib/rules_python/issues/3123)).
* (pypi) Fixes an issue where builds using a `bazel vendor` vendor directory
  would fail if the constraints file contained environment markers. Fixes
  [#2996](https://github.com/bazel-contrib/rules_python/issues/2996).
* (pypi) Wheels with BUILD.bazel (or other special Bazel files) no longer
  result in missing files at runtime
  ([#2782](https://github.com/bazel-contrib/rules_python/issues/2782)).
* (runfiles) The pypi runfiles package now includes `py.typed` to indicate it
  supports type checking
  ([#2503](https://github.com/bazel-contrib/rules_python/issues/2503)).
* (pypi) The pipstar `defaults` configuration now supports any custom platform
  name.
* (pypi) The selection of the whls has been changed and should no longer result
  in ambiguous select matches ({gh-issue}`2759`) and should be much more efficient
  when running `bazel query` due to fewer repositories being included
  ({gh-issue}`2849`).
* Multi-line python imports (e.g. with escaped newlines) are now correctly processed by Gazelle.
* (toolchains) `local_runtime_repo` works with multiarch Debian with Python 3.8
  ([#3099](https://github.com/bazel-contrib/rules_python/issues/3099)).
* (pypi) Expose pypi packages only common to all Python versions in `all_requirements`
  ([#2921](https://github.com/bazel-contrib/rules_python/issues/2921)).
* (repl) Normalize the path for the `REPL` stub to make it possible to use the
  default stub template from outside `rules_python` ({gh-issue}`3101`).
* (gazelle) Fixes gazelle adding sibling module dependencies to resolve
  absolute imports (Python 2's behavior without `absolute_import`). Previous
  behavior can be restored using the directive
  `# gazelle:python_resolve_sibling_imports true`
* (pypi) Show overridden index URL of packages when downloading metadata have failed.
  ([#2985](https://github.com/bazel-contrib/rules_python/issues/2985)).
* (toolchains) use "command -v" to find interpreter in `$PATH`
  ([#3150](https://github.com/bazel-contrib/rules_python/pull/3150)).
* (pypi) `bazel vendor` now works in `bzlmod` ({gh-issue}`3079`).
* (toolchains) `local_runtime_repo` now works on Windows
  ([#3055](https://github.com/bazel-contrib/rules_python/issues/3055)).
* (toolchains) `local_runtime_repo` supports more types of Python
  installations (Mac frameworks, missing dynamic libraries, and other
  esoteric cases, see
  [#3148](https://github.com/bazel-contrib/rules_python/pull/3148) for details).
* (pypi) Support `requirements.txt` files that use different versions of the same
  package targeting different target platforms.
  ([#2797](https://github.com/bazel-contrib/rules_python/issues/2797)).
* (py_wheel) Add directories in deterministic order.

{#v1-6-0-added}
### Added
* (repl) Default stub now has tab completion, where `readline` support is available,
  see ([#3114](https://github.com/bazel-contrib/rules_python/pull/3114)).
  ([#3114](https://github.com/bazel-contrib/rules_python/pull/3114)).
* (pypi) To configure the environment for `requirements.txt` evaluation, use the newly added
  developer preview of the `pip.default` tag class. Only `rules_python` and root modules can use
  this feature. You can also configure custom `config_settings` using `pip.default`. It
  can also be used to set the global `netrc` or `auth_patterns` variables.
* (pypi) PyPI dependencies now expose an `:extracted_whl_files` filegroup target
  of all the files extracted from the wheel. This can be used in lieu of
  {obj}`whl_filegroup` to avoid copying/extracting wheel multiple times to
  get a subset of their files.
* (gazelle) New directive `gazelle:python_generate_pyi_deps`; when `true`,
  dependencies added to satisfy type-only imports (`if TYPE_CHECKING`) and type
  stub packages are added to `pyi_deps` instead of `deps`.
* (toolchain) Add toolchains for aarch64 windows for
    * 3.11.13
    * 3.12.11
    * 3.13.6
    * 3.14.0rc1
* (gazelle): New annotation `gazelle:include_pytest_conftest`. When not set (the
  default) or `true`, gazelle will inject any `conftest.py` file found in the same
  directory as a {obj}`py_test` target to that {obj}`py_test` target's `deps`.
  This behavior is unchanged from previous versions. When `false`, the `:conftest`
  dep is not added to the {obj}`py_test` target.
* (gazelle) New directive `gazelle:python_generate_proto`; when `true`,
  Gazelle generates `py_proto_library` rules for `proto_library`. `false` by default.
    * Note: Users must manually configure their Gazelle target to support the
      proto language.
* (gazelle) New directive `gazelle:python_proto_naming_convention`; controls
  naming of `py_proto_library` rules.

{#v1-6-0-removed}
### Removed
* Nothing removed.

{#v1-5-4}
## [1.5.4] - 2025-08-27

[1.5.4]: https://github.com/bazel-contrib/rules_python/releases/tag/1.5.4

{#v1-5-4-fixed}
### Fixed
* (toolchains) `local_runtime_repo` now checks if the include directory exists
  before attempting to watch it, fixing issues on macOS with system Python
  ([#3043](https://github.com/bazel-contrib/rules_python/issues/3043)).

{#v1-5-3}
## [1.5.3] - 2025-08-11

[1.5.3]: https://github.com/bazel-contrib/rules_python/releases/tag/1.5.3

### Fixed
* (toolchains) `local_runtime_repo` now checks if the include directory exists
  before attempting to watch it, fixing issues on macOS with system Python
  ([#3043](https://github.com/bazel-contrib/rules_python/issues/3043)).

{#v1-5-2}
## [1.5.2] - 2025-08-11

[1.5.2]: https://github.com/bazel-contrib/rules_python/releases/tag/1.5.2

{#v1-5-2-changed}
### Changed
* (deps) (bzlmod) Upgraded to `bazel-skylib` version
  [1.8.1](https://github.com/bazelbuild/bazel-skylib/releases/tag/1.8.1)
  to remove deprecation warnings.

{#v1-5-2-fixed}
### Fixed
* (pypi) Correctly pull `sdist` distributions using `pip`
  ([#3131](https://github.com/bazel-contrib/rules_python/pull/3131)).
* (core) builds work again on `7.x` `WORKSPACE` configurations
  ([#3119](https://github.com/bazel-contrib/rules_python/issues/3119)).

{#v1-5-1}
## [1.5.1] - 2025-07-06

[1.5.1]: https://github.com/bazel-contrib/rules_python/releases/tag/1.5.1

{#v1-5-1-fixed}
### Fixed

* (pypi) Namespace packages work by default (pkgutil shims are generated
  by default again)
  ([#3038](https://github.com/bazel-contrib/rules_python/issues/3038)).

{#v1-5-0}
## [1.5.0] - 2025-06-11

[1.5.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.5.0

{#v1-5-0-changed}
### Changed

* (toolchain) Bundled toolchain version updates:
    * 3.9 now references 3.9.23
    * 3.10 now references 3.10.18
    * 3.11 now references 3.11.13
    * 3.12 now references 3.12.11
    * 3.13 now references 3.13.4
* (rules) On Windows, {obj}`--bootstrap_impl=system_python` is forced. This
  allows setting `--bootstrap_impl=script` in bazelrc for mixed-platform
  environments.
* (rules) {obj}`compile_pip_requirements` now generates a `.test` target. The
  `_test` target is deprecated and will be removed in the next major release.
  ([#2794](https://github.com/bazel-contrib/rules_python/issues/2794)
* (py_wheel) py_wheel always creates zip64-capable wheel zips
* (providers) (experimental) {obj}`PyInfo.venv_symlinks` replaces
  `PyInfo.site_packages_symlinks`
* (deps) Updated setuptools to 78.1.1 to patch CVE-2025-47273. This effectively makes
  Python 3.9 the minimum supported version for using `pip_parse`.

{#v1-5-0-fixed}
### Fixed

* (rules) PyInfo provider is now advertised by py_test, py_binary, and py_library;
  this allows aspects using required_providers to function correctly.
  ([#2506](https://github.com/bazel-contrib/rules_python/issues/2506)).
* Fixes when using {obj}`--bootstrap_impl=script`:
  * `compile_pip_requirements` now works with it
  * The `sys._base_executable` value will reflect the underlying interpreter,
    not venv interpreter.
  * The {obj}`//python/runtime_env_toolchains:all` toolchain now works with it.
* (rules) Better handle flakey platform.win32_ver() calls by calling them
  multiple times.
* (tools/wheelmaker.py) Extras are now preserved in Requires-Dist metadata when using requires_file
  to specify the requirements.
* (pypi) Use bazel downloader for direct URL references and correctly detect the filenames from
  various URL formats - URL encoded version strings get correctly resolved, sha256 value can be
  also retrieved from the URL as opposed to only the `--hash` parameter. Fixes
  [#2363](https://github.com/bazel-contrib/rules_python/issues/2363).
* (pypi) `whl_library` now infers file names from its `urls` attribute correctly.
* (pypi) When running under `bazel test`, be sure that temporary `requirements` file
  remains writable.
* (py_test, py_binary) Allow external files to be used for main
* (pypi) Correctly aggregate the sources when the hashes specified in the lockfile differ
  by platform even though the same version is used. Fixes [#2648](https://github.com/bazel-contrib/rules_python/issues/2648).
* (pypi) `compile_pip_requirements` test rule works behind the proxy
* (toolchains) The hermetic toolchains now correctly statically advertise the
  `releaselevel` and `serial` for pre-release hermetic toolchains ({gh-issue}`2837`).

{#v1-5-0-added}
### Added
* Repo utilities `execute_unchecked`, `execute_checked`, and `execute_checked_stdout` now
  support `log_stdout` and `log_stderr` keyword arg booleans. When these are `True`
  (the default), the subprocess's stdout/stderr will be logged.
* (toolchains) Local toolchains can be activated with custom flags. See
  [Conditionally using local toolchains] docs for how to configure.
* (pypi) Starlark-based evaluation of environment markers (requirements.txt conditionals)
  available (not enabled by default) for improved multi-platform build support.
  Set the `RULES_PYTHON_ENABLE_PIPSTAR=1` environment variable to enable it.
* (utils) Add a way to run a REPL for any `rules_python` target that returns
  a `PyInfo` provider.
* (uv) Handle `.netrc` and `auth_patterns` auth when downloading `uv`. Work towards
  [#1975](https://github.com/bazel-contrib/rules_python/issues/1975).
* (toolchains) Arbitrary python-build-standalone runtimes can be registered
  and activated with custom flags. See the [Registering custom runtimes]
  docs and {obj}`single_version_platform_override()` API docs for more
  information.
* (rules) Added support for a using constraints files with `compile_pip_requirements`.
  Useful when an intermediate dependency needs to be upgraded to pull in
  security patches.
* (toolchains): 3.14.0b2 has been added as a preview.

{#v1-5-0-removed}
### Removed
* Nothing removed.

{#v1-4-2}
## [1.4.2] - 2025-08-13

[1.4.2]: https://github.com/bazel-contrib/rules_python/releases/tag/1.4.2

### Fixed
* (toolchains) `local_runtime_repo` now checks if the include directory exists
  before attempting to watch it, fixing issues on macOS with system Python
  ([#3043](https://github.com/bazel-contrib/rules_python/issues/3043)).

{#v1-4-1}
## [1.4.1] - 2025-05-08

[1.4.1]: https://github.com/bazel-contrib/rules_python/releases/tag/1.4.1

{#v1-4-1-fixed}
### Fixed
* (pypi) Fix a typo not allowing users to benefit from using the downloader when the hashes in the
  requirements file are not present. Fixes
  [#2863](https://github.com/bazel-contrib/rules_python/issues/2863).

{#v1-4-0}
## [1.4.0] - 2025-04-19

[1.4.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.4.0

{#v1-4-0-changed}
### Changed
* (toolchain) The `exec` configuration toolchain now has the forwarded
  `exec_interpreter` now also forwards the `ToolchainInfo` provider. This is
  for increased compatibility with the `RBE` setups where access to the `exec`
  configuration interpreter is needed.
* (toolchains) Use the latest astral-sh toolchain release [20250317] for Python versions:
    * 3.9.21
    * 3.10.16
    * 3.11.11
    * 3.12.9
    * 3.13.2
* (pypi) Use `xcrun xcodebuild --showsdks` to find XCode root.
* (toolchains) Remove all but `3.8.20` versions of the Python `3.8` interpreter who has
  reached EOL. If users still need other versions of the `3.8` interpreter, please supply
  the URLs manually {bzl:obj}`python.toolchain` or {bzl:obj}`python_register_toolchains` calls.
* (toolchains) Previously [#2636](https://github.com/bazel-contrib/rules_python/pull/2636)
  changed the semantics of `ignore_root_user_error` from "ignore" to "warning". This is now
  flipped back to ignoring the issue, and will only emit a warning when the attribute is set
  `False`.
* (pypi) The PyPI extension will no longer write the lock file entries as the
  extension has been marked reproducible.
  Fixes [#2434](https://github.com/bazel-contrib/rules_python/issues/2434).
* (gazelle) Lazily load and parse manifest files when running Gazelle. This ensures no
  manifest files are loaded when Gazelle is run over a set of non-python directories
  [PR #2746](https://github.com/bazel-contrib/rules_python/pull/2746).
* (rules) {attr}`py_binary.srcs` and {attr}`py_test.srcs` is no longer mandatory when
  `main_module` is specified (for `--bootstrap_impl=script`)

[20250317]: https://github.com/astral-sh/python-build-standalone/releases/tag/20250317

{#v1-4-0-fixed}
### Fixed
* (pypi) Platform specific extras are now correctly handled when using
  universal lock files with environment markers. Fixes [#2690](https://github.com/bazel-contrib/rules_python/pull/2690).
* (runfiles) ({obj}`--bootstrap_impl=script`) Follow symlinks when searching for runfiles.
* (toolchains) Do not try to run `chmod` when downloading non-windows hermetic toolchain
  repositories on Windows. Fixes
  [#2660](https://github.com/bazel-contrib/rules_python/issues/2660).
* (logging) Allow repo rule logging level to be set to `FAIL` via the `RULES_PYTHON_REPO_DEBUG_VERBOSITY` environment variable.
* (toolchains) The toolchain matching is has been fixed when writing
  transitions transitioning on the `python_version` flag.
  Fixes [#2685](https://github.com/bazel-contrib/rules_python/issues/2685).
* (toolchains) Run the check on the Python interpreter in isolated mode, to ensure it's not affected by userland environment variables, such as `PYTHONPATH`.
* (toolchains) Ensure temporary `.pyc` and `.pyo` files are also excluded from the interpreters repository files.
* (pypi) Run interpreter version call in isolated mode, to ensure it's not affected by userland environment variables, such as `PYTHONPATH`.
* (packaging) An empty `requires_file` is treated as if it were omitted, resulting in a valid `METADATA` file.
* (rules) py_wheel and sphinxdocs rules now propagate `target_compatible_with` to all targets they create.
  [PR #2788](https://github.com/bazel-contrib/rules_python/pull/2788).
* (pypi) Correctly handle `METADATA` entries when `python_full_version` is used in
  the environment marker.
  Fixes [#2319](https://github.com/bazel-contrib/rules_python/issues/2319).
* (pypi) Correctly handle `python_version` parameter and transition the requirement
  locking to the right interpreter version when using
  {obj}`compile_pip_requirements` rule.
  See [#2819](https://github.com/bazel-contrib/rules_python/pull/2819).

{#v1-4-0-added}
### Added
* (pypi) From now on `sha256` values in the `requirements.txt` is no longer
  mandatory when enabling {attr}`pip.parse.experimental_index_url` feature.
  This means that `rules_python` will attempt to fetch metadata for all
  packages through SimpleAPI unless they are pulled through direct URL
  references. Fixes [#2023](https://github.com/bazel-contrib/rules_python/issues/2023).
  In case you see issues with `rules_python` being too eager to fetch the SimpleAPI
  metadata, you can use the newly added {attr}`pip.parse.simpleapi_skip`
  to skip metadata fetching for those packages.
* (uv) A {obj}`lock` rule that is the replacement for the
  {obj}`compile_pip_requirements`. This may still have rough corners
  so please report issues with it in the
  [#1975](https://github.com/bazel-contrib/rules_python/issues/1975).
  Main highlights - the locking can be done within a build action or outside
  it, there is no more automatic `test` target (but it can be added on the user
  side by using `native_test`). For customizing the `uv` version that is used,
  please check the {obj}`uv.configure` tag class.
* Add support for riscv64 linux platform.
* (toolchains) Add python 3.13.2 and 3.12.9 toolchains
* (providers) (experimental) `PyInfo.site_packages_symlinks` field added to
  allow specifying links to create within the venv site packages (only
  applicable with {obj}`--bootstrap_impl=script`)
  ([#2156](https://github.com/bazelbuild/rules_python/issues/2156)).
* (toolchains) Local Python installs can be used to create a toolchain
  equivalent to the standard toolchains. See [Local toolchains] docs for how to
  configure them.
* (toolchains) Expose `$(PYTHON2_ROOTPATH)` and `$(PYTHON3_ROOTPATH)` which are runfiles
  locations equivalents of `$(PYTHON2)` and `$(PYTHON3) respectively.


{#v1-4-0-removed}
### Removed
* Nothing removed.


{#v1-3-0}
## [1.3.0] - 2025-03-27

[1.3.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.3.0

{#v1-3-0-changed}
### Changed
* (deps) platforms 0.0.4 -> 0.0.11
* (py_wheel) Package `py_library.pyi_srcs` (`.pyi` files) in the wheel.
* (py_package) Package `py_library.pyi_srcs` (`.pyi` files) in `py_package`.
* (gazelle) The generated manifest file (default: `gazelle_python.yaml`) will now include the
  YAML document start `---` line. Implemented in
  [#2656](https://github.com/bazel-contrib/rules_python/pull/2656).

{#v1-3-0-fixed}
### Fixed
* (pypi) The `ppc64le` is now pointing to the right target in the `platforms` package.
* (gazelle) No longer incorrectly merge `py_binary` targets during partial updates in
  `file` generation mode. Fixed in [#2619](https://github.com/bazel-contrib/rules_python/pull/2619).
* (bzlmod) Running as root is no longer an error. `ignore_root_user_error=True`
  is now the default. Note that running as root may still cause spurious
  Bazel cache invalidation
  ([#1169](https://github.com/bazel-contrib/rules_python/issues/1169)).
* (gazelle) Don't collapse depsets to a list or into args when generating the modules mapping file.
  Support spilling modules mapping args into a params file.
* (coverage) Fix missing files in the coverage report if they have no tests.
* (pypi) From now on `python` invocations in repository and module extension
  evaluation contexts will invoke Python interpreter with `-B` to avoid
  creating `.pyc` files.
* (deps) doublestar 4.7.1 (required for recent Gazelle versions)

{#v1-3-0-added}
### Added
* (python) {obj}`python.defaults` has been added to allow users to
  set the default python version in the root module by reading the
  default version number from a file or an environment variable.
* {obj}`//python/bin:python`: convenience target for directly running an
  interpreter. {obj}`--//python/bin:python_src` can be used to specify a
  binary whose interpreter to use.
* (uv) Now the extension can be fully configured via `bzlmod` APIs without the
  need to patch `rules_python`. The documentation has been added to `rules_python`
  docs but usage of the extension may result in your setup breaking without any
  notice. What is more, the URLs and SHA256 values will be retrieved from the
  GitHub releases page metadata published by the `uv` project.
* (pypi) An extra argument to add the interpreter lib dir to `LDFLAGS` when
  building wheels from `sdist`.
* (pypi) Direct HTTP urls for wheels and sdists are now supported when using
  {obj}`experimental_index_url` (bazel downloader).
  Partially fixes [#2363](https://github.com/bazel-contrib/rules_python/issues/2363).
* (rules) APIs for creating custom rules based on the core py_binary, py_test,
  and py_library rules
  ([#1647](https://github.com/bazel-contrib/rules_python/issues/1647))
* (rules) Added env-var to allow additional interpreter args for stage1 bootstrap.
  See {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable.
  Only applicable for {obj}`--bootstrap_impl=script`.
* (rules) Added {obj}`interpreter_args` attribute to `py_binary` and `py_test`,
  which allows pass arguments to the interpreter before the regular args.
* (rules) Added {obj}`main_module` attribute to `py_binary` and `py_test`,
  which allows specifying a module name to run (i.e. `python -m <module>`).

{#v1-3-0-removed}
### Removed
* Nothing removed.

{#v1-2-0}
## [1.2.0] - 2025-02-21

[1.2.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.2.0

{#v1-2-0-changed}
### Changed
* (rules) `py_proto_library` is deprecated in favour of the
  implementation in <https://github.com/protocolbuffers/protobuf>. It will be
  removed in the future release.
* (pypi) {obj}`pip.override` will now be ignored instead of raising an error,
  fixes [#2550](https://github.com/bazel-contrib/rules_python/issues/2550).
* (rules) deprecation warnings for deprecated symbols have been turned off by
  default for now and can be enabled with `RULES_PYTHON_DEPRECATION_WARNINGS`
  env var.
* (pypi) Downgraded versions of packages: `pip` from `24.3.2` to `24.0.0` and
  `packaging` from `24.2` to `24.0`.

{#v1-2-0-fixed}
### Fixed
* (rules) `python_zip_file` output with `--bootstrap_impl=script` works again
  ([#2596](https://github.com/bazel-contrib/rules_python/issues/2596)).
* (docs) Using `python_version` attribute for specifying python versions introduced in `v1.1.0`
* (gazelle) Providing multiple input requirements files to `gazelle_python_manifest` now works correctly.
* (pypi) Handle trailing slashes in pip index URLs in environment variables,
  fixes [#2554](https://github.com/bazel-contrib/rules_python/issues/2554).
* (runfiles) Runfile manifest and repository mapping files are now interpreted
  as UTF-8 on all platforms.
* (coverage) Coverage with `--bootstrap_impl=script` is fixed
  ([#2572](https://github.com/bazel-contrib/rules_python/issues/2572)).
* (pypi) Non deterministic behaviour in requirement file usage has been fixed
  by reverting [#2514](https://github.com/bazel-contrib/rules_python/pull/2514).
  The related issue is [#908](https://github.com/bazel-contrib/rules_python/issue/908).
* (sphinxdocs) Do not crash when `tag_class` does not have a populated `doc` value.
  Fixes ([#2579](https://github.com/bazel-contrib/rules_python/issues/2579)).
* (binaries/tests) Fix packaging when using `--bootstrap_impl=script`: set
  {obj}`--venvs_use_declare_symlink=no` to have it not create symlinks at
  build time (they will be created at runtime instead).
  (Fixes [#2489](https://github.com/bazel-contrib/rules_python/issues/2489))

{#v1-2-0-added}
### Added
* Nothing added.

{#v1-2-0-removed}
### Removed
* Nothing removed.

{#v1-1-0}
## [1.1.0] - 2025-01-07

[1.1.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.1.0

{#v1-1-0-changed}
### Changed
* (toolchains) 3.13 means 3.13.1 (previously 3.13.0)
* Bazel 6 support is dropped and Bazel 7.4.1 is the minimum supported
  version, per our Bazel support matrix. Earlier versions are not
  tested by CI, so functionality cannot be guaranteed.
* ({bzl:obj}`pip.parse`) From now we will make fewer calls to indexes when
  fetching the metadata from SimpleAPI. The calls will be done in parallel to
  each index separately, so the extension evaluation time might slow down if
  not using {bzl:obj}`pip.parse.experimental_index_url_overrides`.
* ({bzl:obj}`pip.parse`) Only query SimpleAPI for packages that have
  sha values in the `requirements.txt` file.
* (rules) The version-aware rules have been folded into the base rules and
  the version-aware rules are now simply aliases for the base rules. The
  `python_version` attribute is still used to specify the Python version.
* (pypi) Updated versions of packages: `pip` to 24.3.1 and
  `packaging` to 24.2.

{#v1-1-0-deprecations}
#### Deprecations
* `//python/config_settings:transitions.bzl` and its `py_binary` and `py_test`
  wrappers are deprecated. Use the regular rules instead.

{#v1-1-0-fixed}
### Fixed
* (py_wheel) Use the default shell environment when building wheels to allow
  toolchains that search PATH to be used for the wheel builder tool.
* (pypi) The requirement argument parsed to `whl_library` will now not have env
  marker information allowing `bazel query` to work in cases where the `whl` is
  available for all of the platforms and the sdist can be built. This fix is
  for both WORKSPACE and `bzlmod` setups.
  Fixes [#2450](https://github.com/bazel-contrib/rules_python/issues/2450).
* (gazelle) Gazelle will now correctly parse Python3.12 files that use [PEP 695 Type
  Parameter Syntax][pep-695]. (#2396)
* (pypi) Using {bzl:obj}`pip_parse.experimental_requirement_cycles` and
  {bzl:obj}`pip_parse.use_hub_alias_dependencies` together now works when
  using WORKSPACE files.
* (pypi) The error messages when the wheel distributions do not match anything
  are now printing more details and include the currently active flag
  values. Fixes [#2466](https://github.com/bazel-contrib/rules_python/issues/2466).
* (py_proto_library) Fix import paths in Bazel 8.
* (whl_library) Now the changes to the dependencies are correctly tracked when
  PyPI packages used in `whl_library` during the repository rule phase
  change. Fixes [#2468](https://github.com/bazel-contrib/rules_python/issues/2468).
+ (gazelle) Gazelle no longer ignores `setup.py` files by default. To restore
  this behavior, apply the `# gazelle:python_ignore_files setup.py` directive.
* Don't re-fetch whl_library, python_repository, etc. repository rules
  whenever `PATH` changes. Fixes
  [#2551](https://github.com/bazel-contrib/rules_python/issues/2551).

[pep-695]: https://peps.python.org/pep-0695/

{#v1-1-0-added}
### Added
* (gazelle) Added `include_stub_packages`  flag to `modules_mapping`. When set to `True`, this
  automatically includes corresponding stub packages for third-party libraries
  that are present and used (e.g., `boto3` → `boto3-stubs`), improving
  type-checking support.
* (pypi) Freethreaded packages are now fully supported in the
  {obj}`experimental_index_url` usage or the regular `pip.parse` usage.
  To select the free-threaded interpreter in the repo phase, please use
  the documented [env](environment-variables) variables.
  Fixes [#2386](https://github.com/bazel-contrib/rules_python/issues/2386).
* (toolchains) Use the latest astral-sh toolchain release [20241206] for Python versions:
    * 3.9.21
    * 3.10.16
    * 3.11.11
    * 3.12.8
    * 3.13.1
* (rules) Attributes for type definition files (`.pyi` files) and type-checking
  only dependencies added. See {obj}`py_library.pyi_srcs` and
  `py_library.pyi_deps` (and the same named attributes for `py_binary` and
  `py_test`).
* (pypi) pypi-generated targets set `pyi_srcs` to include `*.pyi` files.
* (providers) {obj}`PyInfo` has new fields to aid static analysis tools:
  {obj}`direct_original_sources`, {obj}`direct_pyi_files`,
  {obj}`transitive_original_sources`, {obj}`transitive_pyi_files`.

[20241206]: https://github.com/astral-sh/python-build-standalone/releases/tag/20241206

{#v1-1-0-removed}
### Removed
* `find_requirements` in `//python:defs.bzl` has been removed.

{#v1-0-0}
## [1.0.0] - 2024-12-05

[1.0.0]: https://github.com/bazel-contrib/rules_python/releases/tag/1.0.0

{#v1-0-0-changed}
### Changed

**Breaking**:
* (toolchains) stop exposing config settings in python toolchain alias repos.
  Please consider depending on the flags defined in
  `//python/config_setting/...` and the `@platforms` package instead.
* (toolchains) consumers who were depending on the `MACOS_NAME` and the `arch`
  attribute in the `PLATFORMS` list, please update your code to respect the new
  values. The values now correspond to the values available in the
  `@platforms//` package constraint values.
* (toolchains) `host_platform` and `interpreter` constants are no longer created
  in the `toolchain` generated alias `.bzl` files. If you need to access the
  host interpreter during the `repository_rule` evaluation, please use the
  `@python_{version}_host//:python` targets created by
  {bzl:obj}`python_register_toolchains` and
  {bzl:obj}`python_register_multi_toolchains` macros or the {bzl:obj}`python`
  bzlmod extension.
* (bzlmod) `pip.parse.parse_all_requirements_files` attribute has been removed.
  See notes in the previous versions about what to do.
* (deps) rules_cc 0.1.0 (workspace) and 0.0.16 (bzlmod).
* (deps) protobuf 29.0-rc2 (workspace; bzlmod already specifying that version).

Other changes:
* (python_repository) Start honoring the `strip_prefix` field for `zstd` archives.
* (pypi) {bzl:obj}`pip_parse.extra_hub_aliases` now works in WORKSPACE files.
* (binaries/tests) For {obj}`--bootstrap_impl=script`, a binary-specific (but
  otherwise empty) virtual env is used to customize `sys.path` initialization.
* (deps) bazel_skylib 1.7.0 (workspace; bzlmod already specifying that version)
* (deps) bazel_features 1.21.0; necessary for compatibility with Bazel 8 rc3
* (deps) stardoc 0.7.2 to support Bazel 8.

{#v1-0-0-fixed}
### Fixed
* (toolchains) stop depending on `uname` to get the value of the host platform.
* (pypi): Correctly handle multiple versions of the same package in the requirements
  files which is useful when including different PyTorch builds (e.g. <pytorch+cpu> vs <pytorch+cu118> ) for different target platforms.
  Fixes ([2337](https://github.com/bazel-contrib/rules_python/issues/2337)).
* (uv): Correct the sha256sum for the `uv` binary for aarch64-apple-darwin.
  Fixes ([2411](https://github.com/bazel-contrib/rules_python/issues/2411)).
* (binaries/tests) ({obj}`--bootstrap_impl=scipt`) Using `sys.executable` will
  use the same `sys.path` setup as the calling binary.
  ([2169](https://github.com/bazel-contrib/rules_python/issues/2169)).
* (workspace) Corrected protobuf's name to com_google_protobuf, the name is
  hardcoded in Bazel, WORKSPACE mode.
* (pypi): {bzl:obj}`compile_pip_requirements` no longer fails on Windows when `--enable_runfiles` is not enabled.
* (pypi): {bzl:obj}`compile_pip_requirements` now correctly updates files in the source tree on Windows when `--windows_enable_symlinks` is not enabled.
* (repositories): Add libs/python3.lib and pythonXY.dll to the `libpython` target
  defined by a repository template. This enables stable ABI builds of Python extensions
  on Windows (by defining Py_LIMITED_API).
* (rules) `py_test` and `py_binary` targets no longer incorrectly remove the
  first `sys.path` entry when using {obj}`--bootstrap_impl=script`

{#v1-0-0-added}
### Added
* (gazelle): Parser failures will now be logged to the terminal. Additional
  details can be logged by setting `RULES_PYTHON_GAZELLE_VERBOSE=1`.
* (toolchains) allow users to select which variant of the support host toolchain
  they would like to use through
  `RULES_PYTHON_REPO_TOOLCHAIN_{VERSION}_{OS}_{ARCH}` env variable setting. For
  example, this allows one to use `freethreaded` python interpreter in the
  `repository_rule` to build a wheel from `sdist`.
* (toolchain) The python interpreters targeting `muslc` libc have been added
  for the latest toolchain versions for each minor Python version. You can control
  the toolchain selection by using the
  {bzl:obj}`//python/config_settings:py_linux_libc` build flag.
* (providers) Added {obj}`PyRuntimeInfo.site_init_template` and
  {obj}`PyRuntimeInfo.site_init_template` for specifying the template to use to
  initialize the interpreter via venv startup hooks.
* (runfiles) (Bazel 7.4+) Added support for spaces and newlines in runfiles paths

{#v1-0-0-removed}
### Removed
* (pypi): Remove `pypi_install_dependencies` macro that has been included in
  {bzl:obj}`py_repositories` for a long time.
* (bzlmod): Remove `DEFAULT_PYTHON_VERSION` from `interpreters.bzl` file. If
  you need the version, please use it from the `versions.bzl` file instead.

{#v0-40-0}
## [0.40.0] - 2024-11-17

[0.40.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.40.0

{#v0-40-changed}
### Changed
* Nothing changed.

{#v0-40-fixed}
### Fixed
* (rules) Don't drop custom import paths if Bazel-builtin PyInfo is removed.
  ([2414](https://github.com/bazel-contrib/rules_python/issues/2414)).

{#v0-40-added}
### Added
* Nothing added.

{#v0-40-removed}
### Removed
* (publish) Remove deprecated `requirements.txt` for the `twine` dependencies.
  Please use `requirements_linux.txt` instead.
* (python_repository) Use bazel's built in `zstd` support and remove attributes
  for customizing the `zstd` binary to be used for `zstd` archives in the
  {bzl:obj}`python_repository` repository_rule. This affects the
  {bzl:obj}`python_register_toolchains` and
  {bzl:obj}`python_register_multi_toolchains` callers in the `WORKSPACE`.

{#v0-39-0}
## [0.39.0] - 2024-11-13

[0.39.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.39.0

{#v0-39-0-changed}
### Changed
* (deps) bazel_skylib 1.6.1 -> 1.7.1
* (deps) rules_cc 0.0.9 -> 0.0.14
* (deps) protobuf 24.4 -> 29.0-rc2
* (deps) rules_proto 6.0.0-rc1 -> 6.0.2
* (deps) stardoc 0.6.2 -> 0.7.1
* For bzlmod, Bazel 7.4 is now the minimum Bazel version.
* (toolchains) Use the latest indygreg toolchain release [20241016] for Python versions:
    * 3.9.20
    * 3.10.15
    * 3.11.10
    * 3.12.7
    * 3.13.0
* (pypi) The naming scheme for the `bzlmod` spoke repositories have changed as
  all of the given `requirements.txt` files are now parsed by `default`, to
  temporarily restore the behavior, you can use
  {bzl:obj}`pip.parse.extra_hub_aliases`, which will be removed or made noop in
  the future.

[20241016]: https://github.com/indygreg/python-build-standalone/releases/tag/20241016

{#v0-39-0-fixed}
### Fixed
* (precompiling) Skip precompiling (instead of erroring) if the legacy
  `@bazel_tools//tools/python:autodetecting_toolchain` is being used
  ([#2364](https://github.com/bazel-contrib/rules_python/issues/2364)).

{#v0-39-0-added}
### Added
* Bazel 8 is now supported.
* (toolchain) Support for freethreaded Python toolchains is now available. Use
  the config flag `//python/config_settings:py_freethreaded` to toggle the
  selection of the free-threaded toolchains.
* (toolchain) {obj}`py_runtime.abi_flags` attribute and
  {obj}`PyRuntimeInfo.abi_flags` field added.

{#v0-39-0-removed}
### Removed
* Support for Bazel 6 using bzlmod has been dropped.

{#v0-38-0}
## [0.38.0] - 2024-11-08

[0.38.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.38.0

{#v0-38-0-changed}
### Changed
* (deps) (WORKSPACE only) rules_cc 0.0.13 and protobuf 27.0 is now the default
  version used; this for Bazel 8+ support (previously version was rules_cc 0.0.9
  and no protobuf version specified)
  ([2310](https://github.com/bazel-contrib/rules_python/issues/2310)).
* (publish) The dependencies have been updated to the latest available versions
  for the `twine` publishing rule.
* (whl_library) Remove `--no-build-isolation` to allow non-hermetic sdist builds
  by default. Users wishing to keep this argument and to enforce more hermetic
  builds can do so by passing the argument in
  [`pip.parse#extra_pip_args`](https://rules-python.readthedocs.io/en/latest/api/rules_python/python/extensions/pip.html#pip.parse.extra_pip_args)
* (pip.parse) {attr}`pip.parse.whl_modifications` now normalizes the given whl names
  and now `pyyaml` and `PyYAML` will both work.
* (bzlmod) `pip.parse` spoke repository naming will be changed in an upcoming
  release in places where the users specify different package versions per
  platform in the same hub repository. The naming of the spoke repos is
  considered an implementation detail and we advise the users to use the `hub`
  repository directly and make use of {bzl:obj}`pip.parse.extra_hub_aliases`
  feature added in this release.

{#v0-38-0-fixed}
### Fixed
* (pypi) (Bazel 7.4+) Allow spaces in filenames included in `whl_library`s
  ([617](https://github.com/bazel-contrib/rules_python/issues/617)).
* (pypi) When {attr}`pip.parse.experimental_index_url` is set, we need to still
  pass the `extra_pip_args` value when building an `sdist`.
* (pypi) The patched wheel filenames from now on are using local version specifiers
  which fixes usage of the said wheels using standard package managers.
* (bzlmod) The extension evaluation has been adjusted to always generate the
  same lock file irrespective if `experimental_index_url` is set by any module
  or not. To opt into this behavior, set
  `pip.parse.parse_all_requirements_files`, which will become the
  default in future releases leading up to `1.0.0`. Fixes
  [#2268](https://github.com/bazel-contrib/rules_python/issues/2268). A known
  issue is that it may break `bazel query` and in these use cases it is
  advisable to use `cquery` or switch to `download_only = True`

{#v0-38-0-added}
### Added
* (publish) The requirements file for the `twine` publishing rules have been
  updated to have a new convention: `requirements_darwin.txt`,
  `requirements_linux.txt`, `requirements_windows.txt` for each respective OS
  and one extra file `requirements_universal.txt` if you prefer a single file.
  The `requirements.txt` file may be removed in the future.
* The rules_python version is now reported in `//python/features.bzl#features.version`
* (pip.parse) {attr}`pip.parse.extra_hub_aliases` can now be used to expose extra
  targets created by annotations in whl repositories.
  Fixes [#2187](https://github.com/bazel-contrib/rules_python/issues/2187).
* (bzlmod) `pip.parse` now supports `whl-only` setup using
  `download_only = True` where users can specify multiple requirements files
  and use the `pip` backend to do the downloading. This was only available for
  users setting {bzl:obj}`pip.parse.experimental_index_url`, but now users have
  more options whilst we continue to work on stabilizing the experimental feature.

{#v0-37-2}
## [0.37.2] - 2024-10-27

[0.37.2]: https://github.com/bazel-contrib/rules_python/releases/tag/0.37.2

{#v0-37-2-fixed}
### Fixed
* (bzlmod) Generate `config_setting` values for all available toolchains instead
  of only the registered toolchains, which restores the previous behaviour that
  `bzlmod` users would have observed.

{#v0-37-1}
## [0.37.1] - 2024-10-22

[0.37.1]: https://github.com/bazel-contrib/rules_python/releases/tag/0.37.1

{#v0-37-1-fixed}
### Fixed
* (rules) Setting `--incompatible_python_disallow_native_rules` no longer
  causes rules_python rules to fail
  ([#2326](https://github.com/bazel-contrib/rules_python/issues/2326)).

{#v0-37-0}
## [0.37.0] - 2024-10-18

[0.37.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.37.0

{#v0-37-0-changed}
### Changed
* **BREAKING** `py_library` no longer puts its source files or generated pyc
  files in runfiles; it's the responsibility of consumers (e.g. binaries) to
  populate runfiles with the necessary files. Adding source files to runfiles
  can be temporarily restored by setting {obj}`--add_srcs_to_runfiles=enabled`,
  but this flag will be removed in a subsequent releases.
* {obj}`PyInfo.transitive_sources` is now added to runfiles. These files are
  `.py` files that are required to be added to runfiles by downstream binaries
  (or equivalent).
* (toolchains) `py_runtime.implementation_name` now defaults to `cpython`
  (previously it defaulted to None).
* (toolchains) The exec tools toolchain is enabled by default. It can be
  disabled by setting
  {obj}`--@rules_python//python/config_settings:exec_tools_toolchain=disabled`.
* (deps) stardoc 0.6.2 added as dependency.

{#v0-37-0-fixed}
### Fixed
* (bzlmod) The `python.override(minor_mapping)` now merges the default and the
  overridden versions ensuring that the resultant `minor_mapping` will always
  have all of the python versions.
* (bzlmod) The default value for the {obj}`--python_version` flag will now be
  always set to the default python toolchain version value.
* (bzlmod) correctly wire the {attr}`pip.parse.extra_pip_args` all the
  way to `whl_library`. What is more we will pass the `extra_pip_args` to
  `whl_library` for `sdist` distributions when using
  {attr}`pip.parse.experimental_index_url`. See
  [#2239](https://github.com/bazel-contrib/rules_python/issues/2239).
* (whl_filegroup): Provide per default also the `RECORD` file
* (py_wheel): `RECORD` file entry elements are now quoted if necessary when a
  wheel is created
* (whl_library) truncate progress messages from the repo rule to better handle
  case where a requirement has many `--hash=sha256:...` flags
* (rules) `compile_pip_requirements` passes `env` to the `X.update` target (and
  not only to the `X_test` target, a bug introduced in
  [#1067](https://github.com/bazel-contrib/rules_python/pull/1067)).
* (bzlmod) In hybrid bzlmod with WORKSPACE builds,
  `python_register_toolchains(register_toolchains=True)` is respected
  ([#1675](https://github.com/bazel-contrib/rules_python/issues/1675)).
* (precompiling) The {obj}`pyc_collection` attribute now correctly
  enables (or disables) using pyc files from targets transitively
* (pip) Skip patching wheels not matching `pip.override`'s `file`
  ([#2294](https://github.com/bazel-contrib/rules_python/pull/2294)).
* (chore): Add a `rules_shell` dev dependency and moved a `sh_test` target
  outside of the `//:BUILD.bazel` file.
  Fixes [#2299](https://github.com/bazel-contrib/rules_python/issues/2299).

{#v0-37-0-added}
### Added
* (py_wheel) Now supports `compress = (True|False)` to allow disabling
  compression to speed up development.
* (toolchains): A public `//python/config_settings:python_version_major_minor` has
  been exposed for users to be able to match on the `X.Y` version of a Python
  interpreter.
* (api) Added {obj}`merge_py_infos()` so user rules can merge and propagate
  `PyInfo` without losing information.
* (toolchains) New Python versions available: 3.13.0 using the [20241008] release.
* (toolchains): Bump default toolchain versions to:
    * `3.8 -> 3.8.20`
    * `3.9 -> 3.9.20`
    * `3.10 -> 3.10.15`
    * `3.11 -> 3.11.10`
    * `3.12 -> 3.12.7`
* (coverage) Add support for python 3.13 and bump `coverage.py` to 7.6.1.
* (bzlmod) Add support for `download_only` flag to disable usage of `sdists`
  when {bzl:attr}`pip.parse.experimental_index_url` is set.
* (api) PyInfo fields: {obj}`PyInfo.transitive_implicit_pyc_files`,
  {obj}`PyInfo.transitive_implicit_pyc_source_files`.

[20241008]: https://github.com/indygreg/python-build-standalone/releases/tag/20241008

{#v0-37-0-removed}
### Removed
* (precompiling) `--precompile_add_to_runfiles` has been removed.
* (precompiling) `--pyc_collection` has been removed. The `pyc_collection`
  attribute now bases its default on {obj}`--precompile`.
* (precompiling) The {obj}`precompile=if_generated_source` value has been removed.
* (precompiling) The {obj}`precompile_source_retention=omit_if_generated_source` value has been removed.

{#v0-36-0}
## [0.36.0] - 2024-09-24

[0.36.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.36.0

{#v0-36-0-changed}
### Changed
* (gazelle): Update error messages when unable to resolve a dependency to be more human-friendly.
* (flags) The {obj}`--python_version` flag now also returns
  {obj}`config_common.FeatureFlagInfo`.
* (toolchain): The toolchain patches now expose the `patch_strip` attribute
  that one should use when patching toolchains. Please set it if you are
  patching python interpreter. In the next release the default will be set to
  `0` which better reflects the defaults used in public `bazel` APIs.
* (toolchains) When {obj}`py_runtime.interpreter_version_info` isn't specified,
  the {obj}`--python_version` flag will determine the value. This allows
  specifying the build-time Python version for the
  {obj}`runtime_env_toolchains`.
* (toolchains) {obj}`py_cc_toolchain.libs` and {obj}`PyCcToolchainInfo.libs` is
  optional. This is to support situations where only the Python headers are
  available.
* (bazel) Minimum bazel 7 version that we test against has been bumped to `7.1`.

{#v0-36-0-fixed}
### Fixed
* (whl_library): Remove `--no-index` and add `--no-build-isolation` to the
  `pip install` command when installing a wheel from a local file, which happens
  when `experimental_index_url` flag is used.
* (bzlmod) get the path to the host python interpreter in a way that results in
  platform non-dependent hashes in the lock file when the requirement markers need
  to be evaluated.
* (bzlmod) correctly watch sources used for evaluating requirement markers for
  any changes so that the repository rule or module extensions can be
  re-evaluated when the said files change.
* (gazelle): Fix incorrect use of `t.Fatal`/`t.Fatalf` in tests.
* (toolchain) Omit third-party python packages from coverage reports from
  stage2 bootstrap template.
* (bzlmod) Properly handle relative path URLs in parse_simpleapi_html.bzl
* (gazelle) Correctly resolve deps that have top-level module overlap with a gazelle_python.yaml dep module
* (rules) Make `RUNFILES_MANIFEST_FILE`-based invocations work when used with
  {obj}`--bootstrap_impl=script`. This fixes invocations using non-sandboxed
  test execution with `--enable_runfiles=false --build_runfile_manifests=true`.
  ([#2186](https://github.com/bazel-contrib/rules_python/issues/2186)).
* (py_wheel) Fix incorrectly generated `Required-Dist` when specifying requirements with markers
  in extra_requires in py_wheel rule.
* (rules) Prevent pytest from trying run the generated stage2
  bootstrap .py file when using {obj}`--bootstrap_impl=script`
* (toolchain) The `gen_python_config_settings` has been fixed to include
  the flag_values from the platform definitions.

{#v0-36-0-added}
### Added
* (bzlmod): Toolchain overrides can now be done using the new
  {bzl:obj}`python.override`, {bzl:obj}`python.single_version_override` and
  {bzl:obj}`python.single_version_platform_override` tag classes.
  See [#2081](https://github.com/bazel-contrib/rules_python/issues/2081).
* (rules) Executables provide {obj}`PyExecutableInfo`, which contains
  executable-specific information useful for packaging an executable or
  or deriving a new one from the original.
* (py_wheel) Removed use of bash to avoid failures on Windows machines which do not
  have it installed.
* (docs) Automatically generated documentation for {bzl:obj}`python_register_toolchains`
  and related symbols.
* (toolchains) Added {attr}`python_repository.patch_strip` attribute for
  allowing values that are other than `1`, which has been hard-coded up until
  now. If you are relying on the undocumented `patches` support in
  `TOOL_VERSIONS` for registering patched toolchains please consider setting
  the `patch_strip` explicitly to `1` if you depend on this value - in the
  future the value may change to default to `0`.
* (toolchains) Added `//python:none`, a special target for use with
  {obj}`py_exec_tools_toolchain.exec_interpreter` to treat the value as `None`.

{#v0-36-0-removed}
### Removed
* (toolchains): Removed accidentally exposed `http_archive` symbol from
  `python/repositories.bzl`.
* (toolchains): An internal _is_python_config_setting_ macro has been removed.

{#v0-35-0}
## [0.35.0] - 2024-08-15

[0.35.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.35.0

{#v0-35-0-changed}
### Changed
* (whl_library) A better log message when the wheel is built from an sdist or
  when the wheel is downloaded using `download_only` feature to aid debugging.
* (gazelle): Simplify and make gazelle_python.yaml have only top level package name.
  It would work well in cases to reduce merge conflicts.
* (toolchains): Change some old toochain versions to use [20240726] release to
  include dependency updates `3.8.19`, `3.9.19`, `3.10.14`, `3.11.9`
* (toolchains): Bump default toolchain versions to:
    * `3.12 -> 3.12.4`
* (rules) `PYTHONSAFEPATH` is inherited from the calling environment to allow
  disabling it (Requires {obj}`--bootstrap_impl=script`)
  ([#2060](https://github.com/bazel-contrib/rules_python/issues/2060)).

{#v0-35-0-fixed}
### Fixed
* (rules) `compile_pip_requirements` now sets the `USERPROFILE` env variable on
  Windows to work around an issue where `setuptools` fails to locate the user's
  home directory.
* (rules) correctly handle absolute URLs in parse_simpleapi_html.bzl.
* (rules) Fixes build targets linking against `@rules_python//python/cc:current_py_cc_libs`
  in host platform builds on macOS, by editing the `LC_ID_DYLIB` field of the hermetic interpreter's
  `libpython3.x.dylib` using `install_name_tool`, setting it to its absolute path under Bazel's
  execroot.
* (rules) Signals are properly received when using {obj}`--bootstrap_impl=script`
  (for non-zip builds).
  ([#2043](https://github.com/bazel-contrib/rules_python/issues/2043))
* (rules) Fixes Python builds when the `--build_python_zip` is set to `false` on
  Windows. See [#1840](https://github.com/bazel-contrib/rules_python/issues/1840).
* (rules) Fixes Mac + `--build_python_zip` + {obj}`--bootstrap_impl=script`
  ([#2030](https://github.com/bazel-contrib/rules_python/issues/2030)).
* (rules) User dependencies come before runtime site-packages when using
  {obj}`--bootstrap_impl=script`.
  ([#2064](https://github.com/bazel-contrib/rules_python/issues/2064)).
* (rules) Version-aware rules now return both `@_builtins` and `@rules_python`
  providers instead of only one.
  ([#2114](https://github.com/bazel-contrib/rules_python/issues/2114)).
* (pip) Fixed pypi parse_simpleapi_html function for feeds with package metadata
  containing ">" sign
* (toolchains) Added missing executable permission to
  `//python/runtime_env_toolchains` interpreter script so that it is runnable.
  ([#2085](https://github.com/bazel-contrib/rules_python/issues/2085)).
* (pip) Correctly use the `sdist` downloaded by the bazel downloader when using
  `experimental_index_url` feature. Fixes
  [#2091](https://github.com/bazel-contrib/rules_python/issues/2090).
* (gazelle) Make `gazelle_python_manifest.update` manual to avoid unnecessary
  network behavior.
* (bzlmod): The conflicting toolchains during `python` extension will no longer
  cause warnings by default. In order to see the warnings for diagnostic purposes
  set the env var `RULES_PYTHON_REPO_DEBUG_VERBOSITY` to one of `INFO`, `DEBUG` or `TRACE`.
  Fixes [#1818](https://github.com/bazel-contrib/rules_python/issues/1818).
* (runfiles) Make runfiles lookups work for the situation of Bazel 7,
  Python 3.9 (or earlier, where safepath isn't present), and the Rlocation call
  in the same directory as the main file.
  Fixes [#1631](https://github.com/bazel-contrib/rules_python/issues/1631).

{#v0-35-0-added}
### Added
* (rules) `compile_pip_requirements` supports multiple requirements input files as `srcs`.
* (rules) `PYTHONSAFEPATH` is inherited from the calling environment to allow
  disabling it (Requires {obj}`--bootstrap_impl=script`)
  ([#2060](https://github.com/bazel-contrib/rules_python/issues/2060)).
* (gazelle) Added `python_generation_mode_per_package_require_test_entry_point`
  in order to better accommodate users who use a custom macro,
  [`pytest-bazel`][pytest_bazel], [rules_python_pytest] or `rules_py`
  [py_test_main] in order to integrate with `pytest`. Currently the default
  flag value is set to `true` for backwards compatible behaviour, but in the
  future the flag will be flipped be `false` by default.
* (toolchains) New Python versions available: `3.12.4` using the [20240726] release.
* (pypi) Support env markers in requirements files. Note, that this means that
  if your requirements files contain env markers, the Python interpreter will
  need to be run during bzlmod phase to evaluate them. This may incur
  downloading an interpreter (for hermetic-based builds) or cause non-hermetic
  behavior (if using a system Python).

[rules_python_pytest]: https://github.com/caseyduquettesc/rules_python_pytest
[py_test_main]: https://docs.aspect.build/rulesets/aspect_rules_py/docs/rules/#py_pytest_main
[pytest_bazel]: https://pypi.org/project/pytest-bazel
[20240726]: https://github.com/indygreg/python-build-standalone/releases/tag/20240726

{#v0-34-0}
## [0.34.0] - 2024-07-04

[0.34.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.34.0

{#v0-34-0-changed}
### Changed
* `protobuf`/`com_google_protobuf` dependency bumped to `v24.4`
* (bzlmod): optimize the creation of config settings used in pip to
  reduce the total number of targets in the hub repo.
* (toolchains) The exec tools toolchain now finds its interpreter by reusing
  the regular interpreter toolchain. This avoids having to duplicate specifying
  where the runtime for the exec tools toolchain is.
* (toolchains) ({obj}`//python:autodetecting_toolchain`) is deprecated. It is
  replaced by {obj}`//python/runtime_env_toolchains:all`. The old target will be
  removed in a future release.

{#v0-34-0-fixed}
### Fixed
* (bzlmod): When using `experimental_index_url` the `all_requirements`,
  `all_whl_requirements` and `all_data_requirements` will now only include
  common packages that are available on all target platforms. This is to ensure
  that packages that are only present for some platforms are pulled only via
  the `deps` of the materialized `py_library`. If you would like to include
  platform specific packages, using a `select` statement with references to the
  specific package will still work (e.g.
  ```
  my_attr = all_requirements + select(
      {
          "@platforms//os:linux": ["@pypi//foo_available_only_on_linux"],
          "//conditions:default": [],
      }
  )
  ```
* (bzlmod): Targets in `all_requirements` now use the same form as targets returned by the `requirement` macro.
* (rules) Auto exec groups are enabled. This allows actions run by the rules,
  such as precompiling, to pick an execution platform separately from what
  other toolchains support.
* (providers) {obj}`PyRuntimeInfo` doesn't require passing the
  `interpreter_version_info` arg.
* (bzlmod) Correctly pass `isolated`, `quiet` and `timeout` values to `whl_library`
  and drop the defaults from the lock file.
* (whl_library) Correctly handle arch-specific dependencies when we encounter a
  platform specific wheel and use `experimental_target_platforms`.
  Fixes [#1996](https://github.com/bazel-contrib/rules_python/issues/1996).
* (rules) The first element of the default outputs is now the executable again.
* (pip) Fixed crash when pypi packages lacked a sha (e.g. yanked packages)

{#v0-34-0-added}
### Added
* (toolchains) {obj}`//python/runtime_env_toolchains:all`, which is a drop-in
  replacement for the "autodetecting" toolchain.
* (gazelle) Added new `python_label_convention` and `python_label_normalization` directives. These directive
  allows altering default Gazelle label format to third-party dependencies useful for re-using Gazelle plugin
  with other rules, including `rules_pycross`. See [#1939](https://github.com/bazel-contrib/rules_python/issues/1939).

{#v0-34-0-removed}
### Removed
* (pip): Removes the `entrypoint` macro that was replaced by `py_console_script_binary` in 0.26.0.

{#v0-33-2}
## [0.33.2] - 2024-06-13

[0.33.2]: https://github.com/bazel-contrib/rules_python/releases/tag/0.33.2

{#v0-33-2-fixed}
### Fixed
* (toolchains) The {obj}`exec_tools_toolchain_type` is disabled by default.
  To enable it, set {obj}`--//python/config_settings:exec_tools_toolchain=enabled`.
  This toolchain must be enabled for precompilation to work. This toolchain will
  be enabled by default in a future release.
  Fixes [#1967](https://github.com/bazel-contrib/rules_python/issues/1967).

{#v0-33-1}
## [0.33.1] - 2024-06-13

[0.33.1]: https://github.com/bazel-contrib/rules_python/releases/tag/0.33.1

{#v0-33-1-fixed}
### Fixed
* (py_binary) Fix building of zip file when using `--build_python_zip`
  argument. Fixes [#1954](https://github.com/bazel-contrib/rules_python/issues/1954).

{#v0-33-0}
## [0.33.0] - 2024-06-12

[0.33.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.33.0

{#v0-33-0-changed}
### Changed
* (deps) Upgrade the `pip_install` dependencies to pick up a new version of pip.
* (toolchains) Optional toolchain dependency: `py_binary`, `py_test`, and
  `py_library` now depend on the `//python:exec_tools_toolchain_type` for build
  tools.
* (deps): Bumped `bazel_skylib` to 1.6.1.
* (bzlmod): The `python` and internal `rules_python` extensions have been
  marked as `reproducible` and will not include any lock file entries from now
  on.
* (gazelle): Remove gazelle plugin's python deps and make it hermetic.
  Introduced a new Go-based helper leveraging tree-sitter for syntax analysis.
  Implemented the use of `pypi/stdlib-list` for standard library module verification.
* (pip.parse): Do not ignore yanked packages when using `experimental_index_url`.
  This is to mimic what `uv` is doing. We will print a warning instead.
* (pip.parse): Add references to all supported wheels when using `experimental_index_url`
  to allowing to correctly fetch the wheels for the right platform. See the
  updated docs on how to use the feature. This is work towards addressing
  [#735](https://github.com/bazel-contrib/rules_python/issues/735) and
  [#260](https://github.com/bazel-contrib/rules_python/issues/260). The spoke
  repository names when using this flag will have a structure of
  `{pip_hub_prefix}_{wheel_name}_{py_tag}_{abi_tag}_{platform_tag}_{sha256}`,
  which is an implementation detail which should not be relied on and is there
  purely for better debugging experience.
* (bzlmod) The `pythons_hub//:interpreters.bzl` no longer has platform-specific
  labels which where left there for compatibility reasons. Move to
  `python_{version}_host` keys if you would like to have access to a Python
  interpreter that can be used in a repository rule context.

{#v0-33-0-fixed}
### Fixed
* (gazelle) Remove `visibility` from `NonEmptyAttr`.
  Now empty(have no `deps/main/srcs/imports` attr) `py_library/test/binary` rules will
  be automatically deleted correctly. For example, if `python_generation_mode`
  is set to package, when `__init__.py` is deleted, the `py_library` generated
  for this package before will be deleted automatically.
* (whl_library): Use _is_python_config_setting_ to correctly handle multi-python
  version dependency select statements when the `experimental_target_platforms`
  includes the Python ABI. The default python version case within the select is
  also now handled correctly, stabilizing the implementation.
* (gazelle) Fix Gazelle failing on Windows with
  "panic: runtime error: invalid memory address or nil pointer dereference"
* (bzlmod) remove `pip.parse(annotations)` attribute as it is unused and has been
  replaced by whl_modifications.
* (pip) Correctly select wheels when the python tag includes minor versions.
  See ([#1930](https://github.com/bazel-contrib/rules_python/issues/1930))
* (pip.parse): The lock file is now reproducible on any host platform if the
  `experimental_index_url` is not used by any of the modules in the dependency
  chain. To make the lock file identical on each `os` and `arch`, please use
  the `experimental_index_url` feature which will fetch metadata from PyPI or a
  different private index and write the contents to the lock file. Fixes
  [#1643](https://github.com/bazel-contrib/rules_python/issues/1643).
* (pip.parse): Install `yanked` packages and print a warning instead of
  ignoring them. This better matches the behaviour of `uv pip install`.
* (toolchains): Now matching of the default hermetic toolchain is more robust
  and explicit and should fix rare edge-cases where the host toolchain
  autodetection would match a different toolchain than expected. This may yield
  to toolchain selection failures when the python toolchain is not registered,
  but is requested via `//python/config_settings:python_version` flag setting.
* (doc) Fix the `WORKSPACE` requirement vendoring example. Fixes
  [#1918](https://github.com/bazel-contrib/rules_python/issues/1918).

{#v0-33-0-added}
### Added
* (rules) Precompiling Python source at build time is available. but is
  disabled by default, for now. Set
  `@rules_python//python/config_settings:precompile=enabled` to enable it
  by default. A subsequent release will enable it by default. See the
  [Precompiling docs][precompile-docs] and API reference docs for more
  information on precompiling. Note this requires Bazel 7+ and the Pystar rule
  implementation enabled.
  ([#1761](https://github.com/bazel-contrib/rules_python/issues/1761))
* (rules) Attributes and flags to control precompile behavior: `precompile`,
  `precompile_optimize_level`, `precompile_source_retention`,
  `precompile_invalidation_mode`, and `pyc_collection`
* (toolchains) The target runtime toolchain (`//python:toolchain_type`) has
  two new optional attributes: `pyc_tag` (tells the pyc filename infix to use) and
  `implementation_name` (tells the Python implementation name).
* (toolchains) A toolchain type for build tools has been added:
  `//python:exec_tools_toolchain_type`.
* (providers) `PyInfo` has two new attributes: `direct_pyc_files` and
  `transitive_pyc_files`, which tell the pyc files a target makes available
  directly and transitively, respectively.
* `//python:features.bzl` added to allow easy feature-detection in the future.
* (pip) Allow specifying the requirements by (os, arch) and add extra
  validations when parsing the inputs. This is a non-breaking change for most
  users unless they have been passing multiple `requirements_*` files together
  with `extra_pip_args = ["--platform=manylinux_2_4_x86_64"]`, that was an
  invalid usage previously but we were not failing the build. From now on this
  is explicitly disallowed.
* (toolchains) Added riscv64 platform definition for python toolchains.
* (gazelle) The `python_visibility` directive now supports the `$python_root$`
  placeholder, just like the `python_default_visibility` directive does.
* (rules) A new bootstrap implementation that doesn't require a system Python
  is available. It can be enabled by setting
  {obj}`--@rules_python//python/config_settings:bootstrap_impl=script`. It
  will become the default in a subsequent release.
  ([#691](https://github.com/bazel-contrib/rules_python/issues/691))
* (providers) `PyRuntimeInfo` has two new attributes:
  {obj}`PyRuntimeInfo.stage2_bootstrap_template` and
  {obj}`PyRuntimeInfo.zip_main_template`.
* (toolchains) A replacement for the Bazel-builtn autodetecting toolchain is
  available. The `//python:autodetecting_toolchain` alias now uses it.
* (pip): Support fetching and using the wheels for other platforms. This
  supports customizing whether the linux wheels are pulled for `musl` or
  `glibc`, whether `universal2` or arch-specific MacOS wheels are preferred and
  it also allows to select a particular `libc` version. All of this is done via
  the `string_flags` in `@rules_python//python/config_settings`. If there are
  no wheels that are supported for the target platform, `rules_python` will
  fallback onto building the `sdist` from source. This behaviour can be
  disabled if desired using one of the available string flags as well.
* (whl_filegroup) Added a new `whl_filegroup` rule to extract files from a wheel file.
  This is useful to extract headers for use in a `cc_library`.

[precompile-docs]: /precompiling

{#v0-32-2}
## [0.32.2] - 2024-05-14

[0.32.2]: https://github.com/bazel-contrib/rules_python/releases/tag/0.32.2

{#v0-32-2-fixed}
### Fixed

* Workaround existence of infinite symlink loops on case insensitive filesystems when targeting linux platforms with recent Python toolchains. Works around an upstream [issue][indygreg-231]. Fixes [#1800][rules_python_1800].

[indygreg-231]: https://github.com/indygreg/python-build-standalone/issues/231
[rules_python_1800]: https://github.com/bazel-contrib/rules_python/issues/1800

{#v0-32-0}
## [0.32.0] - 2024-05-12

[0.32.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.32.0

{#v0-32-0-changed}
### Changed

* (bzlmod): The `MODULE.bazel.lock` `whl_library` rule attributes are now
  sorted in the attributes section. We are also removing values that are not
  default in order to reduce the size of the lock file.
* (coverage) Bump `coverage.py` to [7.4.3](https://github.com/nedbat/coveragepy/blob/master/CHANGES.rst#version-743--2024-02-23).
* (deps): Bumped `bazel_features` to 1.9.1 to detect optional support
  non-blocking downloads.
* (deps): Updated `pip_tools` to >= 7.4.0
* (toolchains): Change some old toolchain versions to use [20240224] release to
  include security fixes `3.8.18`, `3.9.18` and `3.10.13`
* (toolchains): Bump default toolchain versions to:
    * `3.8 -> 3.8.19`
    * `3.9 -> 3.9.19`
    * `3.10 -> 3.10.14`
    * `3.11 -> 3.11.9`
    * `3.12 -> 3.12.3`

### Fixed

* (whl_library): Fix the experimental_target_platforms overriding for platform
  specific wheels when the wheels are for any python interpreter version. Fixes
  [#1810](https://github.com/bazel-contrib/rules_python/issues/1810).
* (whl_library): Stop generating duplicate dependencies when encountering
  duplicates in the METADATA. Fixes
  [#1873](https://github.com/bazel-contrib/rules_python/issues/1873).
* (gazelle) In `project` or `package` generation modes, do not generate `py_test`
  rules when there are no test files and do not set `main = "__test__.py"` when
  that file doesn't exist.
* (whl_library) The group redirection is only added when the package is part of
  the group potentially fixing aspects that want to traverse a `py_library` graph.
  Fixes [#1760](https://github.com/bazel-contrib/rules_python/issues/1760).
* (bzlmod) Setting a particular micro version for the interpreter and the
  `pip.parse` extension is now possible, see the
  `examples/pip_parse/MODULE.bazel` for how to do it.
  See [#1371](https://github.com/bazel-contrib/rules_python/issues/1371).
* (refactor) The pre-commit developer workflow should now pass `isort` and `black`
  checks (see [#1674](https://github.com/bazel-contrib/rules_python/issues/1674)).

### Added

* (toolchains) Added armv7 platform definition for python toolchains.
* (toolchains) New Python versions available: `3.11.8`, `3.12.2` using the [20240224] release.
* (toolchains) New Python versions available: `3.8.19`, `3.9.19`, `3.10.14`, `3.11.9`, `3.12.3` using
  the [20240415] release.
* (gazelle) Added a new `python_visibility` directive to control visibility
  of generated targets by appending additional visibility labels.
* (gazelle) Added a new `python_default_visibility` directive to control the
  _default_ visibility of generated targets. See the [docs][python_default_visibility]
  for details.
* (gazelle) Added a new `python_test_file_pattern` directive. This directive tells
  gazelle which python files should be mapped to the `py_test` rule. See the
  [original issue][test_file_pattern_issue] and the [docs][test_file_pattern_docs]
  for details.
* (wheel) Add support for `data_files` attributes in py_wheel rule
  ([#1777](https://github.com/bazel-contrib/rules_python/issues/1777))
* (py_wheel) `bzlmod` installations now provide a `twine` setup for the default
  Python toolchain in `rules_python` for version 3.11.
* (bzlmod) New `experimental_index_url`, `experimental_extra_index_urls` and
  `experimental_index_url_overrides` to `pip.parse` for using the bazel
  downloader. If you see any issues, report in
  [#1357](https://github.com/bazel-contrib/rules_python/issues/1357). The URLs for
  the whl and sdist files will be written to the lock file. Controlling whether
  the downloading of metadata is done in parallel can be done using
  `parallel_download` attribute.
* (gazelle) Add a new annotation `include_dep`. Also add documentation for
  annotations to `gazelle/README.md`.
* (deps): `rules_python` depends now on `rules_cc` 0.0.9
* (pip_parse): A new flag `use_hub_alias_dependencies` has been added that is going
  to become default in the next release. This makes use of `dep_template` flag
  in the `whl_library` rule. This also affects the
  `experimental_requirement_cycles` feature where the dependencies that are in
  a group would be only accessible via the hub repo aliases. If you still
  depend on legacy labels instead of the hub repo aliases and you use the
  `experimental_requirement_cycles`, now is a good time to migrate.

[python_default_visibility]: https://github.com/bazel-contrib/rules_python/tree/main/gazelle/README.md#directive-python_default_visibility
[test_file_pattern_issue]: https://github.com/bazel-contrib/rules_python/issues/1816
[test_file_pattern_docs]: https://github.com/bazel-contrib/rules_python/tree/main/gazelle/README.md#directive-python_test_file_pattern
[20240224]: https://github.com/indygreg/python-build-standalone/releases/tag/20240224.
[20240415]: https://github.com/indygreg/python-build-standalone/releases/tag/20240415.


## [0.31.0] - 2024-02-12

[0.31.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.31.0

### Changed

* For Bazel 7, the core rules and providers are now implemented in rules_python
  directly and the rules bundled with Bazel are not used. Bazel 6 and earlier
  continue to use the Bazel builtin symbols. Of particular note, this means,
  under Bazel 7, the builtin global symbol `PyInfo` is **not** the same as what
  is loaded from rules_python. The same is true of `PyRuntimeInfo`.

## [0.30.0] - 2024-02-12

[0.30.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.30.0

### Changed

* (toolchains) Windows hosts always ignore pyc files in the downloaded runtimes.
  This fixes issues due to pyc files being created at runtime and affecting the
  definition of what files were considered part of the runtime.

* (pip_parse) Added the `envsubst` parameter, which enables environment variable
  substitutions in the `extra_pip_args` attribute.

* (pip_repository) Added the `envsubst` parameter, which enables environment
  variable substitutions in the `extra_pip_args` attribute.

### Fixed

* (bzlmod) pip.parse now does not fail with an empty `requirements.txt`.

* (py_wheel) Wheels generated by `py_wheel` now preserve executable bits when
  being extracted by `installer` and/or `pip`.

* (coverage) During the running of lcov, the stdout/stderr was causing test
  failures.  By default, suppress output when generating lcov.  This can be
  overridden by setting 'VERBOSE_COVERAGE'.  This change only affect bazel
  7.x.x and above.

* (toolchain) Changed the `host_toolchain` to symlink all files to support
  Windows host environments without symlink support.

* (PyRuntimeInfo) Switch back to builtin PyRuntimeInfo for Bazel 6.4 and when
  pystar is disabled. This fixes an error about `target ... does not have ...
  PyRuntimeInfo`.
  ([#1732](https://github.com/bazel-contrib/rules_python/issues/1732))

### Added

* (py_wheel) Added `requires_file` and `extra_requires_files` attributes.

* (whl_library) *experimental_target_platforms* now supports specifying the
  Python version explicitly and the output `BUILD.bazel` file will be correct
  irrespective of the python interpreter that is generating the file and
  extracting the `whl` distribution. Multiple python target version can be
  specified and the code generation will generate version specific dependency
  closures but that is not yet ready to be used and may break the build if
  the default python version is not selected using
  `common --@rules_python//python/config_settings:python_version=X.Y.Z`.

* New Python versions available: `3.11.7`, `3.12.1` using
  <https://github.com/indygreg/python-build-standalone/releases/tag/20240107>.

* (toolchain) Allow setting `x.y` as the `python_version` parameter in
  the version-aware `py_binary` and `py_test` rules. This allows users to
  use the same rule import for testing with specific Python versions and
  rely on toolchain configuration and how the latest version takes precedence
  if e.g. `3.8` is selected. That also simplifies `.bazelrc` for any users
  that set the default `python_version` string flag in that way.

* (toolchain) The runtime's shared libraries (libpython.so et al) can be
  accessed using `@rules_python//python/cc:current_py_cc_libs`. This uses
  toolchain resolution, so the files are from the same runtime used to run a
  target. If you were previously using e.g. `@python_3_11//:libpython`, then
  switch to `:current_py_cc_libs` for looser coupling to the underlying runtime
  repo implementation.

* (repo rules) The environment variable `RULES_PYTHON_REPO_DEBUG=1` can be
  set to make repository rules log detailed information about what they're
  up to.

* (coverage) Add support for python 3.12 and bump `coverage.py` to
  7.4.1.


## [0.29.0] - 2024-01-22

[0.29.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.29.0

### Changed

* **BREAKING** The deprecated `incompatible_generate_aliases` feature flags
  from `pip_parse` and `gazelle` got removed. They had been flipped to `True`
  in 0.27.0 release.
* **BREAKING** (wheel) The `incompatible_normalize_name` and
  `incompatible_normalize_version` flags have been removed. They had been
  flipped to `True` in 0.27.0 release.
* (bzlmod) The pip hub repository now uses the newly introduced config settings
  using the `X.Y` python version notation. This improves cross module
  interoperability and allows to share wheels built by interpreters using
  different patch versions.

### Fixed

* (bzlmod pip.parse) Use a platform-independent reference to the interpreter
  pip uses. This reduces (but doesn't eliminate) the amount of
  platform-specific content in `MODULE.bazel.lock` files; Follow
  [#1643](https://github.com/bazel-contrib/rules_python/issues/1643) for removing
  platform-specific content in `MODULE.bazel.lock` files.

* (wheel) The stamp variables inside the distribution name are no longer
  lower-cased when normalizing under PEP440 conventions.

### Added

* (toolchains) `python_register_toolchains` now also generates a repository
  that is suffixed with `_host`, that has a single label `:python` that is a
  symlink to the python interpreter for the host platform. The intended use is
  mainly in `repository_rule`, which are always run using `host` platform
  Python. This means that `WORKSPACE` users can now copy the `requirements.bzl`
  file for vendoring as seen in the updated `pip_parse_vendored` example.

* (runfiles) `rules_python.python.runfiles.Runfiles` now has a static `Create`
  method to make imports more ergonomic. Users should only need to import the
  `Runfiles` object to locate runfiles.

* (toolchains) `PyRuntimeInfo` now includes a `interpreter_version_info` field
  that contains the static version information for the given interpreter.
  This can be set via `py_runtime` when registering an interpreter toolchain,
  and will done automatically for the builtin interpreter versions registered via
  `python_register_toolchains`.
  Note that this only available on the Starlark implementation of the provider.

* (config_settings) Added `//python/config_settings:is_python_X.Y` config
  settings to match on minor Python version. These settings match any `X.Y`
  version instead of just an exact `X.Y.Z` version.

## [0.28.0] - 2024-01-07

[0.28.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.28.0

### Changed

* **BREAKING** (pip_install) the deprecated `pip_install` macro and related
  items have been removed.

* **BREAKING** Support for Bazel 5 has been officially dropped. This release
  was only partially tested with Bazel 5 and may or may not work with Bazel 5.
  Subsequent versions will no longer be tested under Bazel 5.

* (runfiles) `rules_python.python.runfiles` now directly implements type hints
  and drops support for python2 as a result.

* (toolchains) `py_runtime`, `py_runtime_pair`, and `PyRuntimeInfo` now use the
  rules_python Starlark implementation, not the one built into Bazel. NOTE: This
  only applies to Bazel 6+; Bazel 5 still uses the builtin implementation.

* (pip_parse) The parameter `experimental_requirement_cycles` may be provided a
  map of names to lists of requirements which form a dependency
  cycle. `pip_parse` will break the cycle for you transparently. This behavior
  is also available under bzlmod as
  `pip.parse(experimental_requirement_cycles={})`.

* (toolchains) `py_runtime` can now take an executable target. Note: runfiles
  from the target are not supported yet.
  ([#1612](https://github.com/bazel-contrib/rules_python/issues/1612))

* (gazelle) When `python_generation_mode` is set to `file`, create one `py_binary`
  target for each file with `if __name__ == "__main__"` instead of just one
  `py_binary` for the whole module.

* (gazelle) the Gazelle manifest integrity field is now optional. If the
  `requirements` argument to `gazelle_python_manifest` is unset, no integrity
  field will be generated.

### Fixed

* (gazelle) The gazelle plugin helper was not working with Python toolchains 3.11
  and above due to a bug in the helper components not being on PYTHONPATH.

* (pip_parse) The repositories created by `whl_library` can now parse the `whl`
  METADATA and generate dependency closures irrespective of the host platform
  the generation is executed on. This can be turned on by supplying
  `experimental_target_platforms = ["all"]` to the `pip_parse` or the `bzlmod`
  equivalent. This may help in cases where fetching wheels for a different
  platform using `download_only = True` feature.
* (bzlmod pip.parse) The `pip.parse(python_interpreter)` arg now works for
  specifying a local system interpreter.
* (bzlmod pip.parse) Requirements files with duplicate entries for the same
  package (e.g. one for the package, one for an extra) now work.
* (bzlmod python.toolchain) Submodules can now (re)register the Python version
  that rules_python has set as the default.
  ([#1638](https://github.com/bazel-contrib/rules_python/issues/1638))
* (whl_library) Actually use the provided patches to patch the whl_library.
  On Windows the patching may result in files with CRLF line endings, as a result
  the RECORD file consistency requirement is lifted and now a warning is emitted
  instead with a location to the patch that could be used to silence the warning.
  Copy the patch to your workspace and add it to the list if patches for the wheel
  file if you decide to do so.
* (coverage): coverage reports are now created when the version-aware
  rules are used.
  ([#1600](https://github.com/bazel-contrib/rules_python/issues/1600))
* (toolchains) Workspace builds register the py cc toolchain (bzlmod already
  was). This makes e.g. `//python/cc:current_py_cc_headers` Just Work.
  ([#1669](https://github.com/bazel-contrib/rules_python/issues/1669))
* (bzlmod python.toolchain) The value of `ignore_root_user_error` is now decided
  by the root module only.
  ([#1658](https://github.com/bazel-contrib/rules_python/issues/1658))

### Added

* (docs) bzlmod extensions are now documented on rules-python.readthedocs.io
* (docs) Support and backwards compatibility policies have been documented.
  See <https://rules-python.readthedocs.io/en/latest/support.html>
* (gazelle) `file` generation mode can now also add `__init__.py` to the srcs
  attribute for every target in the package. This is enabled through a separate
  directive `python_generation_mode_per_file_include_init`.

## [0.27.0] - 2023-11-16

[0.27.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.27.0

### Changed

* Make `//python/pip_install:pip_repository_bzl` `bzl_library` target internal
  as all of the publicly available symbols (etc. `package_annotation`) are
  re-exported via `//python:pip_bzl` `bzl_library`.

* (gazelle) Gazelle Python extension no longer has runtime dependencies. Using
  `GAZELLE_PYTHON_RUNTIME_DEPS` from `@rules_python_gazelle_plugin//:def.bzl` is
  no longer necessary.

* (pip_parse) The installation of `pip_parse` repository rule toolchain
  dependencies is now done as part of `py_repositories` call.

* (pip_parse) The generated `requirements.bzl` file now has an additional symbol
  `all_whl_requirements_by_package` which provides a map from the normalized
  PyPI package name to the target that provides the built wheel file. Use
  `pip_utils.normalize_name` function from `@rules_python//python:pip.bzl` to
  convert a PyPI package name to a key in the `all_whl_requirements_by_package`
  map.

* (pip_parse) The flag `incompatible_generate_aliases` has been flipped to
  `True` by default on `non-bzlmod` setups allowing users to use the same label
  strings during the transition period. For example, instead of
  `@pypi_foo//:pkg`, you can now use `@pypi//foo` or `@pypi//foo:pkg`. Other
  labels that are present in the `foo` package are `dist_info`, `whl` and
  `data`. Note, that the `@pypi_foo//:pkg` labels are still present for
  backwards compatibility.

* (gazelle) The flag `use_pip_repository_aliases` is now set to `True` by
  default, which will cause `gazelle` to change third-party dependency labels
  from `@pip_foo//:pkg` to `@pip//foo` by default.

* The `compile_pip_requirements` now defaults to `pyproject.toml` if the `src`
  or `requirements_in` attributes are unspecified, matching the upstream
  `pip-compile` behaviour more closely.

* (gazelle) Use relative paths if possible for dependencies added through
  the use of the `resolve` directive.

* (gazelle) When using `python_generation_mode file`, one `py_test` target is
  made per test file even if a target named `__test__` or a file named
  `__test__.py` exists in the same package. Previously in these cases there
  would only be one test target made.

Breaking changes:

* (pip) `pip_install` repository rule in this release has been disabled and
  will fail by default. The API symbol is going to be removed in the next
  version, please migrate to `pip_parse` as a replacement. The `pip_parse`
  rule no longer supports `requirements` attribute, please use
  `requirements_lock` instead.

* (py_wheel) switch `incompatible_normalize_name` and
  `incompatible_normalize_version` to `True` by default to enforce `PEP440`
  for wheel names built by `rules_python`.

* (tools/wheelmaker.py) drop support for Python 2 as only Python 3 is tested.

### Fixed

* Skip aliases for unloaded toolchains. Some Python versions that don't have full
  platform support, and referencing their undefined repositories can break operations
  like `bazel query rdeps(...)`.

* Python code generated from `proto_library` with `strip_import_prefix` can be imported now.

* (py_wheel) Produce deterministic wheel files and make `RECORD` file entries
  follow the order of files written to the `.whl` archive.

* (gazelle) Generate a single `py_test` target when `gazelle:python_generation_mode project`
  is used.

* (gazelle) Move waiting for the Python interpreter process to exit to the shutdown hook
  to make the usage of the `exec.Command` more idiomatic.

* (toolchains) Keep tcl subdirectory in Windows build of hermetic interpreter.

* (bzlmod) sub-modules now don't have the `//conditions:default` clause in the
  hub repos created by `pip.parse`. This should fix confusing error messages
  in case there is a misconfiguration of toolchains or a bug in `rules_python`.

### Added

* (bzlmod) Added `.whl` patching support via `patches` and `patch_strip`
  arguments to the new `pip.override` tag class.

* (pip) Support for using [PEP621](https://peps.python.org/pep-0621/) compliant
  `pyproject.toml` for creating a resolved `requirements.txt` file.

* (utils) Added a `pip_utils` struct with a `normalize_name` function to allow users
  to find out how `rules_python` would normalize a PyPI distribution name.

## [0.26.0] - 2023-10-06

### Changed

* Python version patch level bumps:
  * 3.8.15  -> 3.8.18
  * 3.9.17  -> 3.9.18
  * 3.10.12 -> 3.10.13
  * 3.11.4  -> 3.11.6

* (deps) Upgrade rules_go 0.39.1 -> 0.41.0; this is so gazelle integration works with upcoming Bazel versions

* (multi-version) The `distribs` attribute is no longer propagated. This
  attribute has been long deprecated by Bazel and shouldn't be used.

* Calling `//python:repositories.bzl#py_repositories()` is required. It has
  always been documented as necessary, but it was possible to omit it in certain
  cases. An error about `@rules_python_internal` means the `py_repositories()`
  call is missing in `WORKSPACE`.

* (bzlmod) The `pip.parse` extension will generate os/arch specific lock
  file entries on `bazel>=6.4`.


### Added

* (bzlmod, entry_point) Added {obj}`py_console_script_binary`, which
  allows adding custom dependencies to a package's entry points and customizing
  the `py_binary` rule used to build it.

* New Python versions available: `3.8.17`, `3.11.5` using
  <https://github.com/indygreg/python-build-standalone/releases/tag/20230826>.

* (gazelle) New `# gazelle:python_generation_mode file` directive to support
  generating one `py_library` per file.

* (python_repository) Support `netrc` and `auth_patterns` attributes to enable
  authentication against private HTTP hosts serving Python toolchain binaries.

* `//python:packaging_bzl` added, a `bzl_library` for the Starlark
  files `//python:packaging.bzl` requires.
* (py_wheel) Added the `incompatible_normalize_name` feature flag to
  normalize the package distribution name according to latest Python
  packaging standards. Defaults to `False` for the time being.
* (py_wheel) Added the `incompatible_normalize_version` feature flag
  to normalize the package version according to PEP440 standard. This
  also adds support for local version specifiers (versions with a `+`
  in them), in accordance with PEP440. Defaults to `False` for the
  time being.

* New Python versions available: `3.8.18`, `3.9.18`, `3.10.13`, `3.11.6`, `3.12.0` using
  <https://github.com/indygreg/python-build-standalone/releases/tag/20231002>.
  `3.12.0` support is considered beta and may have issues.

### Removed

* (bzlmod) The `entry_point` macro is no longer supported and has been removed
  in favour of the `py_console_script_binary` macro for `bzlmod` users.

* (bzlmod) The `pip.parse` no longer generates `{hub_name}_{py_version}` hub repos
  as the `entry_point` macro has been superseded by `py_console_script_binary`.

* (bzlmod) The `pip.parse` no longer generates `{hub_name}_{distribution}` hub repos.

### Fixed

* (whl_library) No longer restarts repository rule when fetching external
  dependencies improving initial build times involving external dependency
  fetching.

* (gazelle) Improve runfiles lookup hermeticity.

[0.26.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.26.0

## [0.25.0] - 2023-08-22

### Changed

* Python version patch level bumps:
  * 3.9.16 -> 3.9.17
  * 3.10.9 -> 3.10.12
  * 3.11.1 -> 3.11.4
* (bzlmod) `pip.parse` can no longer automatically use the default
  Python version; this was an unreliable and unsafe behavior. The
  `python_version` arg must always be explicitly specified.

### Fixed

* (docs) Update docs to use correct bzlmod APIs and clarify how and when to use
  various APIs.
* (multi-version) The `main` arg is now correctly computed and usually optional.
* (bzlmod) `pip.parse` no longer requires a call for whatever the configured
  default Python version is.

### Added

* Created a changelog.
* (gazelle) Stop generating unnecessary imports.
* (toolchains) s390x supported for Python 3.9.17, 3.10.12, and 3.11.4.

[0.25.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.25.0

## [0.24.0] - 2023-07-11

### Changed

* **BREAKING** (gazelle) Gazelle 0.30.0 or higher is required
* (bzlmod) `@python_aliases` renamed to `@python_versions
* (bzlmod) `pip.parse` arg `name` renamed to `hub_name`
* (bzlmod) `pip.parse` arg `incompatible_generate_aliases` removed and always
  true.

### Fixed

* (bzlmod) Fixing Windows Python Interpreter symlink issues
* (py_wheel) Allow twine tags and args
* (toolchain, bzlmod) Restrict coverage tool visibility under bzlmod
* (pip) Ignore temporary pyc.NNN files in wheels
* (pip) Add format() calls to glob_exclude templates
* plugin_output in py_proto_library rule

### Added

* Using Gazelle's lifecycle manager to manage external processes
* (bzlmod) `pip.parse` can be called multiple times with different Python
  versions
* (bzlmod) Allow bzlmod `pip.parse` to reference the default python toolchain and interpreter
* (bzlmod) Implementing wheel annotations via `whl_mods`
* (gazelle) support multiple requirements files in manifest generation
* (py_wheel) Support for specifying `Description-Content-Type` and `Summary` in METADATA
* (py_wheel) Support for specifying `Project-URL`
* (compile_pip_requirements) Added `generate_hashes` arg (default True) to
  control generating hashes
* (pip) Create all_data_requirements alias
* Expose Python C headers through the toolchain.

[0.24.0]: https://github.com/bazel-contrib/rules_python/releases/tag/0.24.0
